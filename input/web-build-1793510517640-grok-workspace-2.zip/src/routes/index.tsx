import { createFileRoute } from '@tanstack/react-router'
import type { ReactNode } from "react";
import {
  Bell,
  Download,
  MessageSquareText,
  Mic,
  ShieldCheck,
  Volume2,
} from "lucide-react";

export const Route = createFileRoute("/")({ component: Home });

const checks = [
  { name: "সরাসরি চ্যাট", result: "পড়ে, নাম সহ" },
  { name: "গ্রুপ, নাম না থাকলে", result: "পড়ে না" },
  { name: "রহিম বনাম রহিমা", result: "আলাদা ধরে" },
  { name: "পুরনো ও ডুপ্লিকেট", result: "এড়িয়ে যায়" },
  { name: "কল, রিঅ্যাকশন, ডিলিট", result: "পড়ে না" },
  { name: "উত্তর", result: "হ্যাঁর আগে পাঠায় না" },
  { name: "ভুল চ্যাট", result: "পাঠায় না" },
  { name: "স্টপ / থামো না", result: "থামে / উত্তর থাকে" },
  { name: "ভয়েস ফাইল নেই", result: "বলে, ক্র্যাশ করে না" },
  { name: "লগে বার্তার লেখা", result: "থাকে না" },
];

function Home() {
  return (
    <main className="mx-auto flex w-full max-w-5xl flex-col gap-8 px-5 py-8 sm:px-8 sm:py-12">
      <header className="flex flex-col gap-4">
        <p className="text-sm font-semibold tracking-wide text-green">Android অ্যাপ · সংস্করণ ১.১.০</p>
        <h1 className="font-serif text-4xl leading-tight font-semibold text-ink sm:text-6xl">কথাবলার বন্ধু</h1>
        <p className="max-w-2xl text-lg leading-relaxed text-muted">
          হোয়াটসঅ্যাপ, মেসেঞ্জার আর টেলিগ্রামের আসা বার্তা বাংলায় পড়ে। উত্তর আপনি বলেন।
          অ্যাপ নিজে কোনো কথা বানায় না।
        </p>
        <div className="flex flex-col gap-3 sm:flex-row">
          <a
            href="/kothabolar-bondhu.apk"
            download
            className="inline-flex h-14 items-center justify-center gap-2 rounded-full bg-green px-6 text-base font-semibold text-green-ink"
          >
            <Download aria-hidden="true" className="size-5" />
            APK ডাউনলোড
          </a>
          <p className="max-w-sm self-center text-sm leading-relaxed text-muted">
            ফোনে নামিয়ে ইনস্টল করুন। এই পাতা শুধু সেটআপের গাইড — এখানে বার্তা পড়া হয় না।
          </p>
        </div>
      </header>

      <section className="grid gap-3 sm:grid-cols-3">
        <Fact icon={Volume2} title="জোরে পড়ে" body="নাম বলছে: তারপর কথা। একের পর এক, গায়ে গায়ে না।" />
        <Fact icon={Mic} title="কথায় উত্তর" body="লেখা দেখিয়ে জিজ্ঞাসা করে। হ্যাঁ বা পাঠাও না বললে যায় না।" />
        <Fact icon={ShieldCheck} title="ফোনেই থাকে" body="আসা বার্তা ডিস্কে সেভ হয় না। আমাদের সার্ভার নেই।" />
      </section>

      <section className="grid gap-4 lg:grid-cols-2">
        <Card title="যা করা হয়">
          <ul className="flex flex-col gap-2 text-base leading-relaxed">
            <li>হোয়াটসঅ্যাপ, হোয়াটসঅ্যাপ বিজনেস, মেসেঞ্জার, মেসেঞ্জার লাইট, টেলিগ্রাম।</li>
            <li>সরাসরি চ্যাট পড়ে। গ্রুপ শুধু নাম বা @ট্যাগ থাকলে।</li>
            <li>২০ সেকেন্ডের পুরনো নোটিফিকেশন ও একই বার্তা আর পড়ে না।</li>
            <li>ভয়েস নোট চালানোর চেষ্টা করে। ফাইল না পেলে বলে “একটি ভয়েস বার্তা”।</li>
            <li>স্টপ, থামো, চুপ করো — শুধু পড়া বা শোনার সময়। সারি খালি করে।</li>
            <li>উত্তর সেই নোটিফিকেশনের RemoteInput দিয়ে, একই চ্যাটে।</li>
          </ul>
        </Card>
        <Card title="Android যা দেয় না">
          <ul className="flex flex-col gap-2 text-base leading-relaxed">
            <li>চ্যাট অ্যাপের ভেতরের ডাটাবেস পড়া যায় না। শুধু নোটিফিকেশন।</li>
            <li>গ্রুপে আলাদা মানুষকে ব্যক্তিগত উত্তর যায় না। গেলে গ্রুপেই যায়, আর সেটা আগে বলে।</li>
            <li>ভয়েস নোটের ফাইল অনেক সময় অন্য অ্যাপ লুকিয়ে রাখে।</li>
            <li>লক স্ক্রিনে মাইক সব ফোনে খোলে না। না খুললে পাঠায় না, বলে দেয়।</li>
            <li>সব সময় মাইক খুলে রাখা যায় না। স্টপ শুধু সক্রিয় থাকাকালীন।</li>
            <li>কথা চেনা ফোনের স্পিচ সার্ভিস দিয়ে। সেটি নিজে নেট ব্যবহার করতে পারে।</li>
          </ul>
        </Card>
      </section>

      <section className="rounded-card border border-line bg-card p-5 sm:p-7">
        <div className="mb-4 flex items-center gap-2">
          <Bell aria-hidden="true" className="size-5 text-green" />
          <h2 className="font-serif text-2xl font-semibold">ফোনে বসানোর ধাপ</h2>
        </div>
        <ol className="flex flex-col gap-3 text-base leading-relaxed">
          <li>১. APK ডাউনলোড করে ইনস্টল করুন। অচেনা অ্যাপের অনুমতি লাগতে পারে।</li>
          <li>২. নোটিফিকেশন অ্যাক্সেস দিন। না দিলে একটি বার্তাও পড়া যায় না।</li>
          <li>৩. মাইক্রোফোন দিন, আর Android ১৩ হলে নিজের নোটিফিকেশন দেখানোর অনুমতি দিন।</li>
          <li>৪. ফোনে বাংলা (বাংলাদেশ) কণ্ঠ বসান। ইংরেজি কণ্ঠ দিয়ে ভান করা হয় না।</li>
          <li>৫. ব্যাটারি অপটিমাইজেশন থেকে একবার ছাড় দিন। নইলে অনেক ফোন লক অবস্থায় অ্যাপ বন্ধ করে।</li>
          <li>৬. গ্রুপে যে নামে ডাকে সেটি লিখুন। খালি থাকলে গ্রুপ পড়া হয় না।</li>
          <li>৭. চালু করুন। কেউ সরাসরি লিখলে শুনবেন: নাম বলছে, তারপর কথা।</li>
          <li>৮. উত্তর বলুন। লেখা মিলিয়ে হ্যাঁ বলুন বা পাঠাও চাপুন। না বললে কিছু যায় না।</li>
        </ol>
      </section>

      <section>
        <div className="mb-4 flex items-center gap-2">
          <MessageSquareText aria-hidden="true" className="size-5 text-green" />
          <h2 className="font-serif text-2xl font-semibold">যা পরীক্ষা করা হয়েছে</h2>
        </div>
        <p className="mb-4 max-w-3xl text-base leading-relaxed text-muted">
          নিয়মগুলো ফোন ছাড়াই JVM-এ চালানো হয়েছে। আসল হোয়াটসঅ্যাপ নোটিফিকেশন এই কম্পিউটারে আসে না,
          তাই ফোনে লাগিয়ে শুনে দেখা বাকি। নিচে যা সবুজ, সেটা কোডে সত্যিই পরীক্ষিত।
        </p>
        <div className="overflow-hidden rounded-card border border-line bg-card">
          <table className="w-full text-left text-sm sm:text-base">
            <thead className="bg-paper text-muted">
              <tr>
                <th className="px-4 py-3 font-semibold">নিয়ম</th>
                <th className="px-4 py-3 font-semibold">ফলাফল</th>
              </tr>
            </thead>
            <tbody>
              {checks.map((row) => (
                <tr key={row.name} className="border-t border-line">
                  <td className="px-4 py-3">{row.name}</td>
                  <td className="px-4 py-3 text-green">{row.result}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <footer className="pb-6 text-sm leading-relaxed text-muted">
        প্রতিটি অনুমতি অ্যাপের ভেতরে বাংলায় লেখা আছে। বার্তার মূল লেখা লগে বা ডিস্কে রাখা হয় না।
        এইমাত্র পাঠানো উত্তর ৩০ সেকেন্ড শুধু মেমোরিতে থাকে, যাতে সেটি আবার পড়ে না ফেলে।
      </footer>
    </main>
  );
}

function Fact({
  icon: Icon,
  title,
  body,
}: {
  icon: typeof Volume2;
  title: string;
  body: string;
}) {
  return (
    <article className="rounded-card border border-line bg-card p-4">
      <Icon aria-hidden="true" className="mb-3 size-5 text-clay" />
      <h2 className="font-serif text-xl font-semibold">{title}</h2>
      <p className="mt-1 text-sm leading-relaxed text-muted">{body}</p>
    </article>
  );
}

function Card({ title, children }: { title: string; children: ReactNode }) {
  return (
    <article className="rounded-card border border-line bg-card p-5 sm:p-6">
      <h2 className="mb-3 font-serif text-2xl font-semibold">{title}</h2>
      {children}
    </article>
  );
}
