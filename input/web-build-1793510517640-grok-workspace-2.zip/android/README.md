# কথাবলার বন্ধু

Hands-free bridge for people in Bangladesh. It reads real WhatsApp, Messenger, and Telegram notifications aloud in Bengali and, after the person confirms, sends that spoken reply with the notification's own direct-reply action. It is not a chatbot. Nothing here invents a reply.

This folder is an Android Studio project (Kotlin, Jetpack Compose, minSdk 26, targetSdk 35). `./gradlew :app:testDebugUnitTest` runs the rule tests on the JVM. `./gradlew :app:assembleDebug` builds an installable APK.

## What stays asleep

`NotificationListenerService` is the only wake path. There is no poll, no alarm, and no always-on microphone. `BridgeForegroundService` starts when a message is accepted and stops itself when the queue, the voice note, and the reply window are finished. It returns `START_NOT_STICKY`. A partial wake lock is acquired only for that session and is capped at 60 seconds. A media session is active only for that same window so a modern phone accepts the playback foreground service.

The stop words স্টপ, থামো, and চুপ করো are armed only while speaking or listening. A whole-utterance match is required, so "থামো না" and a normal sentence are replies. Stock Android does not give a normal app an always-on hotword.

## Confirm before send

A spoken reply is held in memory and shown on screen and on a notification. It is sent only after হ্যাঁ / পাঠাও, or the পাঠাও action. না, বাতিল, স্টপ, a timeout that is still unclear, or a newer chat drops it. The send uses the `RemoteInput` stored for that same conversation id and package. A mismatch sends nothing.

Group mentions are read aloud. A reply, if the notification actually has a reply action, goes to that group chat after the confirmation says the group name. Android does not offer a private reply to the mentioner.

## Phone setup

1. Install the APK. Read the disclosure.
2. Grant notification access, microphone, and (Android 13+) posting notifications.
3. Install a Bengali (Bangladesh) text-to-speech voice. Without `bn-BD` data the app will not fake it with an English voice.
4. Exempt the app from battery optimization once, or some phones will kill the listener.
5. Save the person's names and tags. Turn the switch on.
6. Ask someone to send a direct message. The phone speaks `নাম বলছে: কথা`. Answer out loud. Check the text. Say হ্যাঁ or tap পাঠাও.
7. Say থামো while it is speaking. Speech stops immediately and nothing is sent.

SpeechRecognizer may send audio to the device speech service. This app has no server and does not upload message text itself. Incoming message bodies are not written to disk or to the log.
