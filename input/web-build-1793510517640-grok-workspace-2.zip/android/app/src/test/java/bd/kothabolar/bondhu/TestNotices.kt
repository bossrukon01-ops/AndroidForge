package bd.kothabolar.bondhu

import bd.kothabolar.bondhu.domain.NoticeCategory
import bd.kothabolar.bondhu.domain.NoticeMessage
import bd.kothabolar.bondhu.domain.PolicySettings
import bd.kothabolar.bondhu.domain.RawNotice
import bd.kothabolar.bondhu.domain.RecentReply
import bd.kothabolar.bondhu.domain.TargetApps

internal fun notice(
    pkg: String = "com.whatsapp",
    title: String = "করিম",
    text: String = "আসছ?",
    postedAt: Long = NOW,
    group: Boolean = false,
    summary: Boolean = false,
    category: NoticeCategory = NoticeCategory.MESSAGE,
    messaging: Boolean = true,
    messages: List<NoticeMessage>? = null,
    reply: Boolean = true,
    audio: String? = null,
    key: String = "k-$title-$text",
    snapshot: Boolean = false,
    channel: String? = null,
    conversationTitle: String? = null,
): RawNotice {
    val lines = messages ?: listOf(NoticeMessage(title, text, postedAt))
    return RawNotice(
        key = key,
        packageName = pkg,
        postedAt = postedAt,
        title = title,
        text = text,
        conversationTitle = conversationTitle,
        isGroupConversation = group,
        isGroupSummary = summary,
        category = category,
        messagingStyle = messaging,
        messages = lines,
        hasReplyAction = reply,
        audioUri = audio,
        channelId = channel,
        fromInitialSnapshot = snapshot,
    )
}

internal fun settings(
    now: Long = NOW,
    aliases: List<String> = listOf("রহিম"),
    packages: Set<String> = TargetApps.packages.keys,
    replies: List<RecentReply> = emptyList(),
    readAloud: Boolean = true,
    voiceReply: Boolean = true,
    notes: Boolean = true,
) = PolicySettings(aliases, packages, now, replies, readAloud, voiceReply, notes)

internal const val NOW = 5_000_000L
