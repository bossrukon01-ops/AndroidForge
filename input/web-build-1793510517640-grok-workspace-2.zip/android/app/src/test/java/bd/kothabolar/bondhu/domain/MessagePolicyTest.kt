package bd.kothabolar.bondhu.domain

import bd.kothabolar.bondhu.NOW
import bd.kothabolar.bondhu.notice
import bd.kothabolar.bondhu.settings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MessagePolicyTest {
    @Test
    fun directMessageIsSpokenWithTheSenderName() {
        val decision = evaluate(notice(), settings(), emptySet())
        val speak = decision as Decision.Speak
        assertEquals("R-DM", speak.rule)
        assertEquals("করিম", speak.sender)
        assertEquals("করিম বলছে: আসছ?", speak.speech)
        assertEquals("com.whatsapp", speak.packageName)
        assertEquals("com.whatsapp::করিম", speak.conversationId)
        assertFalseGroup(speak.group)
    }

    @Test
    fun filtersPackageAppMuteStaleSnapshotAndNoise() {
        assertEquals("R-PACKAGE", (evaluate(notice(pkg = "com.android.mms"), settings(), emptySet()) as Decision.Ignore).rule)
        assertEquals(
            "R-APP-OFF",
            (evaluate(notice(), settings(packages = setOf("org.telegram.messenger")), emptySet()) as Decision.Ignore).rule,
        )
        assertEquals("R-MUTE", (evaluate(notice(), settings(readAloud = false), emptySet()) as Decision.Ignore).rule)
        assertEquals("R-SNAPSHOT", (evaluate(notice(snapshot = true), settings(), emptySet()) as Decision.Ignore).rule)
        assertEquals(
            "R-STALE",
            (evaluate(notice(postedAt = NOW - 21_000), settings(), emptySet()) as Decision.Ignore).rule,
        )
        assertEquals(
            "R-DUPLICATE",
            (evaluate(notice(), settings(), setOf(dedupeKey(notice()))) as Decision.Ignore).rule,
        )
        assertEquals(
            "R-CATEGORY",
            (evaluate(notice(category = NoticeCategory.CALL), settings(), emptySet()) as Decision.Ignore).rule,
        )
        assertEquals(
            "R-CALL-TEXT",
            (evaluate(notice(text = "Missed voice call"), settings(), emptySet()) as Decision.Ignore).rule,
        )
        assertEquals(
            "R-REACTION",
            (evaluate(notice(text = "reacted to your message"), settings(), emptySet()) as Decision.Ignore).rule,
        )
        assertEquals(
            "R-DELETED",
            (evaluate(notice(text = "This message was deleted"), settings(), emptySet()) as Decision.Ignore).rule,
        )
        assertEquals(
            "R-ECHO",
            (evaluate(
                notice(text = "আসছি"),
                settings(replies = listOf(RecentReply("com.whatsapp::করিম", "আসছি", NOW))),
                emptySet(),
            ) as Decision.Ignore).rule,
        )
        assertEquals(
            "R-SELF",
            (evaluate(
                notice(messages = listOf(NoticeMessage("করিম", "আসছি", NOW, isSelf = true))),
                settings(),
                emptySet(),
            ) as Decision.Ignore).rule,
        )
    }

    @Test
    fun groupsNeedARealMention() {
        val quiet = notice(title = "পরিবার", text = "কাল আসবে", group = true, messages = listOf(NoticeMessage("সাকিব", "কাল আসবে", NOW)))
        assertEquals("R-GROUP-NO-MENTION", (evaluate(quiet, settings(), emptySet()) as Decision.Ignore).rule)
        assertEquals(
            "R-GROUP-NO-ALIAS",
            (evaluate(quiet, settings(aliases = emptyList()), emptySet()) as Decision.Ignore).rule,
        )
        val named = quiet.copy(
            text = "রহিম কাল আসবে",
            messages = listOf(NoticeMessage("সাকিব", "রহিম কাল আসবে", NOW)),
        )
        val speak = evaluate(named, settings(), emptySet()) as Decision.Speak
        assertEquals("R-MENTION", speak.rule)
        assertTrue(speak.group)
        assertEquals("সাকিব", speak.sender)

        val lookalike = quiet.copy(
            text = "রহিমা কাল আসবে",
            messages = listOf(NoticeMessage("সাকিব", "রহিমা কাল আসবে", NOW)),
        )
        assertEquals("R-GROUP-NO-MENTION", (evaluate(lookalike, settings(), emptySet()) as Decision.Ignore).rule)

        val dm = notice(text = "সরাসরি", messages = listOf(NoticeMessage("করিম", "সরাসরি", NOW)))
        assertEquals("R-DM", (evaluate(dm, settings(aliases = emptyList()), emptySet()) as Decision.Speak).rule)
    }

    @Test
    fun ambiguousColonFormIsAGroup() {
        val hidden = notice(
            title = "করিম",
            text = "সাকিব: কাল যাবি",
            messaging = false,
            messages = emptyList(),
        )
        assertEquals("R-AMBIGUOUS-GROUP", (evaluate(hidden, settings(), emptySet()) as Decision.Ignore).rule)
        val mentioned = hidden.copy(text = "সাকিব: রহিম কাল যাবি")
        val speak = evaluate(mentioned, settings(), emptySet()) as Decision.Speak
        assertEquals("R-MENTION", speak.rule)
        assertEquals("সাকিব", speak.sender)
        assertTrue(speak.group)
    }

    @Test
    fun plainTextFromTelegramIsStillAMessage() {
        val telegram = notice(
            pkg = "org.telegram.messenger",
            title = "নাসরিন",
            text = "পৌঁছে গেছি",
            category = NoticeCategory.OTHER,
            messaging = false,
            messages = emptyList(),
        )
        val speak = evaluate(telegram, settings(), emptySet()) as Decision.Speak
        assertEquals("R-DM", speak.rule)
        assertEquals("নাসরিন", speak.sender)
        assertEquals("org.telegram.messenger", speak.packageName)
    }

    @Test
    fun voiceNoteFallsBackWhenTheFileIsMissingOrDisabled() {
        val withFile = notice(text = "voice message", audio = "content://voice/1")
        assertTrue(evaluate(withFile, settings(), emptySet()) is Decision.PlayVoice)
        assertTrue(evaluate(withFile, settings(notes = false), emptySet()) is Decision.AnnounceVoice)
        val noFile = notice(
            text = "",
            messages = listOf(NoticeMessage("করিম", "", NOW, mime = "audio/ogg")),
        )
        val announced = evaluate(noFile, settings(), emptySet()) as Decision.AnnounceVoice
        assertEquals("একটি ভয়েস বার্তা", announced.body)
        assertEquals("করিম বলছে: একটি ভয়েস বার্তা", announced.speech)
    }

    private fun assertFalseGroup(group: Boolean) {
        assertTrue(!group)
    }
}
