package bd.kothabolar.bondhu.bridge

import bd.kothabolar.bondhu.NOW
import bd.kothabolar.bondhu.domain.NoticeMessage
import bd.kothabolar.bondhu.notice
import bd.kothabolar.bondhu.settings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SessionFlowTest {
    @Test
    fun samePersonIsSpokenBackToBackThenOneListen() {
        val engine = SessionEngine()
        val first = engine.onNotification(dm("এক", "a"), settings())
        engine.onNotification(dm("দুই", "b"), settings())
        assertEquals(1, engine.queue.size)
        val done = engine.onPlaybackDone(speakId(first))
        assertTrue(done.first() is Effect.Speak)
        assertEquals("করিম বলছে: দুই", (done.first() as Effect.Speak).text)
        assertEquals(Phase.SPEAKING, engine.phase)
    }

    @Test
    fun aDifferentPersonWaitsUntilTheReplyWindowEnds() {
        val engine = SessionEngine()
        val first = engine.onNotification(dm("এক", "a"), settings())
        engine.onNotification(dm("হাই", "b", title = "জামাল"), settings())
        val settled = engine.onPlaybackDone(speakId(first))
        assertTrue(settled.single() is Effect.ArmSettle)
        val listen = engine.onSettle()
        assertTrue(listen.single() is Effect.Listen)
        assertEquals("করিম", (listen.single() as Effect.Listen).sender)
        assertEquals(1, engine.queue.size)
        val next = engine.onListenTimeout(NOW)
        assertEquals("জামাল বলছে: হাই", next.filterIsInstance<Effect.Speak>().single().text)
    }

    @Test
    fun replyIsNotSentUntilTheSameConversationIsConfirmed() {
        val engine = primed()
        val heard = engine.onHeard("আমি আসব", NOW)
        assertTrue(heard.single() is Effect.Confirm)
        assertEquals("আমি আসব", engine.pending()?.text)
        assertEquals("করিম", engine.pending()?.destination)
        assertEquals(Phase.CONFIRMING, engine.phase)

        val sent = engine.onHeard("হ্যাঁ", NOW)
        val send = sent.filterIsInstance<Effect.Send>().single()
        assertEquals("আমি আসব", send.text)
        assertEquals("com.whatsapp::করিম", send.conversationId)
        assertEquals("com.whatsapp", send.packageName)
        assertEquals("করিম", send.sender)
        assertNull(engine.pending())
    }

    @Test
    fun buttonConfirmSendsTheRecognizedTextNotTheWordYes() {
        val engine = primed()
        engine.onHeard("কাল আসব", NOW)
        val sent = engine.acceptPending(NOW)
        assertEquals("কাল আসব", sent.filterIsInstance<Effect.Send>().single().text)
    }

    @Test
    fun noAndStopAndASecondChatNeverSend() {
        val rejected = primed()
        val no = rejected.onHeard("আমি আসব", NOW).let { rejected.onHeard("না", NOW) }
        assertTrue(no.none { it is Effect.Send })
        assertNull(rejected.pending())

        val stopped = primed()
        stopped.onHeard("আমি আসব", NOW)
        val halt = stopped.onHeard("স্টপ", NOW)
        assertTrue(halt.none { it is Effect.Send })
        assertEquals(Phase.ASLEEP, stopped.phase)
        assertTrue(stopped.queue.isEmpty())

        val interrupted = primed()
        interrupted.onHeard("আমি আসব", NOW)
        val other = interrupted.onNotification(dm("নতুন", "z", title = "জামাল"), settings())
        assertTrue(other.none { it is Effect.Send })
        assertTrue(other.any { it is Effect.CancelConfirm })
        assertNull(interrupted.pending())
        assertEquals("জামাল বলছে: নতুন", other.filterIsInstance<Effect.Speak>().single().text)
    }

    @Test
    fun unclearConfirmCancelsInsteadOfSending() {
        val engine = primed()
        engine.onHeard("আমি আসব", NOW)
        val again = engine.onHeard("হুম মনে হয়", NOW)
        assertTrue(again.single() is Effect.ConfirmAgain)
        assertEquals("আমি আসব", engine.pending()?.text)
        val dropped = engine.onHeard("আরেকটা কথা", NOW)
        assertTrue(dropped.none { it is Effect.Send })
        assertNull(engine.pending())
    }

    @Test
    fun unsupportedReplyIsExplainedAndDisabledReplyStaysQuiet() {
        val engine = SessionEngine()
        val spoken = engine.onNotification(dm("হাই", "a", reply = false), settings())
        engine.onPlaybackDone(speakId(spoken))
        val explained = engine.onSettle()
        val line = explained.filterIsInstance<Effect.Speak>().single().text
        assertTrue(line.contains("রিপ্লাই"))
        assertTrue(explained.none { it is Effect.Listen })

        val quiet = SessionEngine()
        val first = quiet.onNotification(dm("হাই", "a"), settings(voiceReply = false))
        quiet.onPlaybackDone(speakId(first))
        val after = quiet.onSettle()
        assertTrue(after.single() is Effect.Sleep)
        assertEquals("R-REPLY-OFF", quiet.log.first().rule)
        assertTrue(after.none { it is Effect.Listen })
    }

    @Test
    fun stopClearsTheQueueAndLogsNoMessageText() {
        val engine = SessionEngine()
        engine.onNotification(dm("গোপনকথাএক", "a"), settings())
        engine.onNotification(dm("গোপনকথাদুই", "b", title = "জামাল"), settings())
        assertTrue(engine.log.none { it.detail.contains("গোপনকথা") })
        val halted = engine.halt(NOW, "স্টপ")
        assertTrue(halted.none { it is Effect.Send })
        assertTrue(engine.queue.isEmpty())
        assertEquals(Phase.ASLEEP, engine.phase)
        assertTrue(halted.any { it is Effect.CancelAudio })
        assertFalseDetailHasSpeech(engine)
    }

    @Test
    fun floodCollapsesAndSummaryWaitsForAChild() {
        val engine = SessionEngine()
        repeat(12) { index ->
            engine.onNotification(dm("বার্তা$index", "k$index"), settings())
        }
        engine.onNotification(dm("বার্তা১২", "k12"), settings())
        assertEquals("R-FLOOD", engine.log.first().rule)

        val summaries = SessionEngine()
        val summary = notice(
            title = "পরিবার",
            text = "রহিম হাই",
            group = true,
            summary = true,
            key = "sum",
            messages = listOf(NoticeMessage("সাকিব", "রহিম হাই", NOW)),
        )
        val held = summaries.onNotification(summary, settings())
        assertTrue(held.any { it is Effect.ArmSummary })
        assertEquals(Phase.ASLEEP, summaries.phase)
        summaries.onNotification(
            notice(
                title = "পরিবার",
                text = "রহিম হাই বন্ধু",
                group = true,
                key = "child",
                messages = listOf(NoticeMessage("সাকিব", "রহিম হাই বন্ধু", NOW)),
            ),
            settings(),
        )
        summaries.onNotification(summary.copy(key = "sum2"), settings())
        assertEquals("dropped", summaries.log.first().outcome)
    }

    @Test
    fun snapshotSeedIsNeverReadBack() {
        val engine = SessionEngine()
        val old = dm("পুরনো", "old")
        assertTrue(engine.seed(listOf(old), NOW).isEmpty())
        val again = engine.onNotification(old, settings())
        assertTrue(again.isEmpty())
        assertEquals("R-DUPLICATE", engine.log.first().rule)
        val fresh = engine.onNotification(dm("নতুন", "new"), settings())
        assertTrue(fresh.any { it is Effect.Speak })
    }

    private fun primed(): SessionEngine {
        val engine = SessionEngine()
        val spoken = engine.onNotification(dm("হাই", "a"), settings())
        engine.onPlaybackDone(speakId(spoken))
        val listen = engine.onSettle()
        assertTrue(listen.single() is Effect.Listen)
        return engine
    }

    private fun speakId(effects: List<Effect>): String =
        effects.filterIsInstance<Effect.Speak>().first().id

    private fun dm(
        text: String,
        key: String,
        title: String = "করিম",
        reply: Boolean = true,
    ) = notice(
        title = title,
        text = text,
        key = key,
        postedAt = NOW,
        reply = reply,
        messages = listOf(NoticeMessage(title, text, NOW + key.hashCode())),
    )

    private fun assertFalseDetailHasSpeech(engine: SessionEngine) {
        assertTrue(engine.log.none { it.detail.contains("গোপন") })
    }
}
