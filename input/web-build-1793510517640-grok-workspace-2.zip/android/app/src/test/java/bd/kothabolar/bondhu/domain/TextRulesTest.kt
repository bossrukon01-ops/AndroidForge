package bd.kothabolar.bondhu.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TextRulesTest {
    @Test
    fun mentionDoesNotMatchALongerName() {
        assertTrue(mentioned("রহিম কাল আসবে", listOf("রহিম")))
        assertFalse(mentioned("রহিমা কাল আসবে", listOf("রহিম")))
        assertFalse(mentioned("Rahima is here", listOf("Rahim")))
        assertTrue(mentioned("hello @Rahim please", listOf("Rahim")))
        assertTrue(mentioned("@রহিম", listOf("রহিম")))
        assertFalse(mentioned("হাই", listOf("")))
        assertFalse(mentioned("রহিম", emptyList()))
    }

    @Test
    fun stopIsTheWholeUtteranceOnly() {
        assertTrue(isStopCommand("থামো"))
        assertTrue(isStopCommand("স্টপ"))
        assertTrue(isStopCommand("চুপ করো"))
        assertTrue(isStopCommand("প্লিজ থামো"))
        assertTrue(isStopCommand("Stop"))
        assertFalse(isStopCommand("থামো না"))
        assertFalse(isStopCommand("একটু থামো"))
        assertFalse(isStopCommand("আজকে আমি থামতে চাই না"))
        assertEquals(UtteranceKind.REPLY, classifyUtterance("থামো না"))
        assertEquals(UtteranceKind.STOP, classifyUtterance("চুপ করো"))
        assertEquals(UtteranceKind.REPLY, classifyUtterance("আমি আসব"))
        assertEquals(UtteranceKind.EMPTY, classifyUtterance("   "))
    }

    @Test
    fun confirmIsOnlyShortYesOrNo() {
        assertEquals(ConfirmChoice.YES, classifyConfirm("হ্যাঁ"))
        assertEquals(ConfirmChoice.YES, classifyConfirm("হ্যাঁ।"))
        assertEquals(ConfirmChoice.YES, classifyConfirm("হ্যাঁ পাঠাও"))
        assertEquals(ConfirmChoice.YES, classifyConfirm("OK"))
        assertEquals(ConfirmChoice.NO, classifyConfirm("না"))
        assertEquals(ConfirmChoice.NO, classifyConfirm("পাঠিও না"))
        assertEquals(ConfirmChoice.NO, classifyConfirm("বাতিল"))
        assertEquals(ConfirmChoice.STOP, classifyConfirm("স্টপ"))
        assertEquals(ConfirmChoice.UNCLEAR, classifyConfirm("নাম জানো"))
        assertEquals(ConfirmChoice.UNCLEAR, classifyConfirm("হ্যাঁ মানে কাল আসব না প্লিজ"))
        assertEquals(ConfirmChoice.UNCLEAR, classifyConfirm(""))
    }

    @Test
    fun speechAndSanitizeStayLocal() {
        assertEquals("করিম বলছে: আসছ?", formatSpeech("করিম", "আসছ?"))
        assertEquals("দেখ একটি লিংক", sanitizeBody("দেখ https://example.com/secret"))
        assertTrue(sanitizeBody("ক").length == 1)
        assertTrue(sanitizeBody("ক".repeat(400)).endsWith("…"))
        assertTrue(sanitizeBody("ক".repeat(400)).length <= 280)
    }
}
