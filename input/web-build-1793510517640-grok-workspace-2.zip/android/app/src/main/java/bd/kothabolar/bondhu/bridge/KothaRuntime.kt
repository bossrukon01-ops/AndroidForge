package bd.kothabolar.bondhu.bridge

import android.Manifest
import android.app.Notification
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.service.notification.StatusBarNotification
import android.widget.Toast
import androidx.core.content.ContextCompat
import bd.kothabolar.bondhu.KothaApp
import bd.kothabolar.bondhu.KothaLog
import bd.kothabolar.bondhu.audio.VoiceNotePlayer
import bd.kothabolar.bondhu.domain.RawNotice
import bd.kothabolar.bondhu.domain.conversationId
import bd.kothabolar.bondhu.domain.formatSpeech
import bd.kothabolar.bondhu.domain.isStopCommand
import bd.kothabolar.bondhu.reply.DirectReplySender
import bd.kothabolar.bondhu.service.BridgeForegroundService
import bd.kothabolar.bondhu.service.KothaNotifications
import bd.kothabolar.bondhu.stt.BargeInListener
import bd.kothabolar.bondhu.tts.BengaliSpeaker
import bd.kothabolar.bondhu.util.SafeWakeLock
import java.util.concurrent.CopyOnWriteArrayList

class KothaRuntime(private val app: Context) {
    private val thread = HandlerThread("kotha-session").apply { start() }
    private val handler = Handler(thread.looper)
    private val main = Handler(Looper.getMainLooper())
    private val engine = SessionEngine()
    private val wake = SafeWakeLock(app)
    private val player = VoiceNotePlayer(app)
    private val barge = BargeInListener(app)
    private val audio = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val replies = HashMap<String, ReplySlot>()
    private val keyToConversation = HashMap<String, String>()
    private val summaryGen = HashMap<String, Int>()
    private val summaryConv = HashMap<String, String>()
    private val listeners = CopyOnWriteArrayList<(UiStatus) -> Unit>()
    private val mediaSession = MediaSession(app, "kotha")
    private var bargeArms = 0
    private var settleGen = 0
    private var listenGen = 0
    private var confirmGen = 0

    @Volatile var status: UiStatus = UiStatus()
        private set

    @Volatile var ttsMissing: Boolean = false
        private set

    private val speaker = BengaliSpeaker(
        context = app,
        onUtteranceDone = { id -> handler.post { onSpoken(id) } },
        onLanguageMissing = {
            ttsMissing = true
            handler.post { publish() }
        },
    )

    private val focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build(),
        )
        .setOnAudioFocusChangeListener({ change ->
            if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                handler.post {
                    if (engine.phase != Phase.ASLEEP) {
                        apply(engine.halt(System.currentTimeMillis(), "কল"), null)
                    }
                }
            }
        }, handler)
        .build()

    fun addStatusListener(listener: (UiStatus) -> Unit) {
        listeners.add(listener)
        listener(status)
    }

    fun removeStatusListener(listener: (UiStatus) -> Unit) {
        listeners.remove(listener)
    }

    fun acceptPending() {
        handler.post {
            confirmGen++
            listenGen++
            barge.disarm()
            apply(engine.acceptPending(System.currentTimeMillis()), null)
        }
    }

    fun rejectPending() {
        handler.post {
            confirmGen++
            listenGen++
            barge.disarm()
            apply(engine.rejectPending(System.currentTimeMillis()), null)
        }
    }

    fun seed(existing: List<StatusBarNotification>) {
        handler.post {
            val notices = existing.mapNotNull { sbn ->
                runCatching { NoticeMapper.map(sbn) }.getOrNull()
            }
            engine.seed(notices, System.currentTimeMillis())
            publish()
        }
    }

    fun onPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == app.packageName) return
        handler.post {
            if (!store.enabled) return@post
            val notice = try {
                NoticeMapper.map(sbn)
            } catch (error: Exception) {
                KothaLog.w("map", error)
                return@post
            }
            val conv = conversationId(notice)
            replies[conv] = ReplySlot(sbn.notification, sbn.packageName, sbn.key)
            keyToConversation[sbn.key] = conv
            apply(engine.onNotification(notice, store.snapshot(System.currentTimeMillis())), notice)
        }
    }

    fun onRemoved(key: String) {
        handler.post {
            val conv = keyToConversation.remove(key) ?: return@post
            if (replies[conv]?.key == key) replies.remove(conv)
        }
    }

    fun speakSample() {
        handler.post {
            ensureAwake()
            speaker.speak("sample", "কথাবলার বন্ধু বলছে: আমি শুনতে পাচ্ছি", store.speechRate)
        }
    }

    fun shutdown() {
        handler.post {
            speaker.shutdown()
            player.stop()
            barge.disarm()
            wake.release()
            runCatching { mediaSession.release() }
            thread.quitSafely()
        }
    }

    private fun onSpoken(id: String) {
        if (id == "confirm-prompt") {
            if (engine.phase == Phase.CONFIRMING) armConfirmListen()
            return
        }
        if (id.startsWith("sys") || id == "sample") {
            if (id == "sample" && engine.phase == Phase.ASLEEP && engine.queue.isEmpty()) release()
            return
        }
        apply(engine.onPlaybackDone(id), null)
    }

    private fun apply(effects: List<Effect>, source: RawNotice?) {
        for (effect in effects) {
            when (effect) {
                is Effect.Speak -> {
                    ensureAwake()
                    bargeArms = 0
                    speaker.speak(effect.id, effect.text, store.speechRate)
                    armBarge()
                }
                is Effect.Play -> {
                    ensureAwake()
                    bargeArms = 0
                    player.play(
                        uri = effect.uri,
                        onDone = { handler.post { apply(engine.onPlaybackDone(effect.id), null) } },
                        onFail = {
                            handler.post {
                                val sender = engine.active?.sender ?: "কেউ"
                                speaker.speak(effect.id, formatSpeech(sender, "একটি ভয়েস বার্তা"), store.speechRate)
                            }
                        },
                    )
                    armBarge()
                }
                Effect.CancelAudio -> {
                    speaker.stop()
                    player.stop()
                    barge.disarm()
                }
                Effect.CancelListen -> {
                    listenGen++
                    barge.disarm()
                }
                Effect.ArmSettle -> {
                    val token = ++settleGen
                    handler.postDelayed({
                        if (token == settleGen && engine.phase == Phase.SETTLING) {
                            apply(engine.onSettle(), null)
                        }
                    }, 600)
                }
                Effect.CancelSettle -> settleGen++
                is Effect.Listen -> startListen()
                is Effect.Confirm -> {
                    barge.disarm()
                    confirmGen++
                    KothaNotifications.showConfirm(app, effect.destination, effect.text, effect.group)
                    ensureAwake()
                    speaker.speak("confirm-prompt", promptOf(effect), store.speechRate)
                }
                Effect.ConfirmAgain -> {
                    barge.disarm()
                    confirmGen++
                    ensureAwake()
                    speaker.speak("confirm-prompt", "হ্যাঁ বললে পাঠাব। না বললে বাতিল।", store.speechRate)
                }
                Effect.CancelConfirm -> {
                    confirmGen++
                    listenGen++
                    barge.disarm()
                    KothaNotifications.cancelConfirm(app)
                }
                is Effect.ArmSummary -> holdSummary(effect.hash, source)
                is Effect.CancelSummary -> cancelSummaries(effect.hash, effect.conversationId)
                is Effect.Send -> {
                    KothaNotifications.cancelConfirm(app)
                    send(effect)
                }
                Effect.Sleep -> {
                    KothaNotifications.cancelConfirm(app)
                    release()
                }
            }
        }
        publish()
    }

    private fun startListen() {
        ensureAwake()
        if (!micGranted()) {
            speaker.speak("sys-nomic", "মাইক্রোফোনের অনুমতি নেই। উত্তর পাঠানো হয়নি।", store.speechRate)
            handler.post {
                if (engine.phase == Phase.LISTENING) {
                    apply(engine.onListenTimeout(System.currentTimeMillis()), null)
                }
            }
            return
        }
        val token = ++listenGen
        barge.disarm()
        barge.arm(
            onPartial = { text ->
                if (isStopCommand(text)) handler.post { if (token == listenGen) haltNow() }
            },
            onFinal = { text ->
                handler.post {
                    if (token != listenGen || engine.phase != Phase.LISTENING) return@post
                    listenGen++
                    apply(engine.onHeard(text, System.currentTimeMillis()), null)
                }
            },
            onFailure = {
                handler.post {
                    if (token != listenGen || engine.phase != Phase.LISTENING) return@post
                    listenGen++
                    speaker.speak("sys-miss", "কথা বোঝা যায়নি। কিছু পাঠানো হয়নি।", store.speechRate)
                    apply(engine.onListenTimeout(System.currentTimeMillis()), null)
                }
            },
        )
        handler.postDelayed({
            if (token != listenGen || engine.phase != Phase.LISTENING) return@postDelayed
            listenGen++
            barge.disarm()
            apply(engine.onListenTimeout(System.currentTimeMillis()), null)
        }, 8_000)
    }

    private fun armConfirmListen() {
        if (engine.phase != Phase.CONFIRMING) return
        if (!micGranted()) {
            speaker.speak("sys-nomic", "মাইক্রোফোনের অনুমতি নেই। উত্তর পাঠানো হয়নি।", store.speechRate)
            apply(engine.rejectPending(System.currentTimeMillis()), null)
            return
        }
        val token = ++confirmGen
        barge.arm(
            onPartial = { text ->
                if (isStopCommand(text)) {
                    handler.post {
                        if (token != confirmGen || engine.phase != Phase.CONFIRMING) return@post
                        confirmGen++
                        haltNow()
                    }
                }
            },
            onFinal = { text ->
                handler.post {
                    if (token != confirmGen || engine.phase != Phase.CONFIRMING) return@post
                    confirmGen++
                    barge.disarm()
                    apply(engine.onHeard(text, System.currentTimeMillis()), null)
                }
            },
            onFailure = {
                handler.post {
                    if (token != confirmGen || engine.phase != Phase.CONFIRMING) return@post
                    confirmGen++
                    barge.disarm()
                    apply(engine.onHeard("", System.currentTimeMillis()), null)
                }
            },
        )
        handler.postDelayed({
            if (token != confirmGen || engine.phase != Phase.CONFIRMING) return@postDelayed
            confirmGen++
            barge.disarm()
            apply(engine.onHeard("", System.currentTimeMillis()), null)
        }, 12_000)
    }

    private fun holdSummary(hash: String, source: RawNotice?) {
        if (source == null) return
        val token = (summaryGen[hash] ?: 0) + 1
        summaryGen[hash] = token
        summaryConv[hash] = conversationId(source)
        handler.postDelayed({
            if (summaryGen[hash] != token) return@postDelayed
            if (!store.enabled) return@postDelayed
            val promoted = source.copy(
                isGroupSummary = false,
                key = source.key + ":promoted",
                fromInitialSnapshot = false,
            )
            apply(engine.onNotification(promoted, store.snapshot(System.currentTimeMillis())), promoted)
        }, 800)
    }

    private fun cancelSummaries(hash: String, conversation: String) {
        val doomed = summaryConv.filterValues { it == conversation }.keys + hash
        for (item in doomed) summaryGen[item] = (summaryGen[item] ?: 0) + 1
    }

    private fun send(effect: Effect.Send) {
        val slot = replies[effect.conversationId]
        if (slot == null || slot.packageName != effect.packageName) {
            KothaLog.w("R-REPLY-MISS")
            speaker.speak("sys-fail", "পাঠানো যায়নি। চ্যাটের রিপ্লাই আর নেই।", store.speechRate)
            toastFail()
            return
        }
        when (DirectReplySender.send(app, slot.notification, effect.text)) {
            DirectReplySender.Result.Sent -> {
                KothaLog.i("R-REPLY")
                speaker.speak("sys-sent", "পাঠানো হয়েছে।", store.speechRate)
            }
            DirectReplySender.Result.NoAction, DirectReplySender.Result.Canceled -> {
                KothaLog.w("R-REPLY-FAIL")
                speaker.speak("sys-fail", "পাঠানো যায়নি। এই চ্যাটে রিপ্লাই বোতাম নেই।", store.speechRate)
                toastFail()
            }
            else -> {
                KothaLog.w("R-REPLY-FAIL")
                speaker.speak("sys-fail", "পাঠানো যায়নি।", store.speechRate)
                toastFail()
            }
        }
    }

    private fun armBarge() {
        if (!micGranted()) return
        if (bargeArms >= 3) return
        bargeArms += 1
        barge.arm(
            onPartial = { text ->
                if (isStopCommand(text)) handler.post { haltNow() }
            },
            onFinal = { text ->
                handler.post {
                    if (isStopCommand(text)) {
                        haltNow()
                    } else if (engine.phase == Phase.SPEAKING || engine.phase == Phase.PLAYING) {
                        armBarge()
                    }
                }
            },
            onFailure = {
                handler.post {
                    if (engine.phase == Phase.SPEAKING || engine.phase == Phase.PLAYING) armBarge()
                }
            },
        )
    }

    private fun haltNow() {
        apply(engine.halt(System.currentTimeMillis(), "স্টপ"), null)
    }

    private fun ensureAwake() {
        wake.acquire()
        markPlaying()
        runCatching { audio.requestAudioFocus(focusRequest) }
        try {
            ContextCompat.startForegroundService(app, Intent(app, BridgeForegroundService::class.java))
        } catch (error: Exception) {
            KothaLog.w("fgs-blocked", error)
        }
    }

    private fun release() {
        listenGen++
        settleGen++
        confirmGen++
        barge.disarm()
        player.stop()
        markStopped()
        runCatching { audio.abandonAudioFocusRequest(focusRequest) }
        wake.release()
        app.stopService(Intent(app, BridgeForegroundService::class.java))
    }

    private fun markPlaying() {
        runCatching {
            mediaSession.setPlaybackState(
                PlaybackState.Builder()
                    .setActions(PlaybackState.ACTION_STOP)
                    .setState(PlaybackState.STATE_PLAYING, 0L, 1f)
                    .build(),
            )
            mediaSession.isActive = true
        }
    }

    private fun markStopped() {
        runCatching {
            mediaSession.setPlaybackState(
                PlaybackState.Builder()
                    .setState(PlaybackState.STATE_STOPPED, 0L, 0f)
                    .build(),
            )
            mediaSession.isActive = false
        }
    }

    private fun publish() {
        val pending = engine.pending()
        val line = engine.log.firstOrNull()
        val snap = UiStatus(
            phase = phaseLabel(engine.phase),
            detail = line?.detail ?: "নোটিফিকেশনের অপেক্ষায়।",
            pendingSender = pending?.sender,
            pendingText = pending?.text,
            pendingDestination = pending?.destination,
            pendingGroup = pending?.group == true,
            speakingSender = engine.active?.sender ?: engine.batchAnchor?.sender,
            ttsMissing = ttsMissing,
        )
        status = snap
        main.post { listeners.forEach { it(snap) } }
    }

    private fun phaseLabel(phase: Phase): String = when (phase) {
        Phase.ASLEEP -> "ঘুমাচ্ছে"
        Phase.SPEAKING -> "পড়ছে"
        Phase.PLAYING -> "ভয়েস বাজাচ্ছে"
        Phase.SETTLING -> "একটু অপেক্ষা"
        Phase.LISTENING -> "উত্তর শুনছে"
        Phase.CONFIRMING -> "পাঠানোর আগে দেখুন"
    }

    private fun promptOf(effect: Effect.Confirm): String {
        val dest = if (effect.group) "${effect.destination} গ্রুপে পাঠাব" else "${effect.destination}কে পাঠাব"
        return "আপনি বললেন: ${effect.text}. $dest? হ্যাঁ বলুন। না বললে বাতিল।"
    }

    private fun micGranted(): Boolean =
        ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun toastFail() {
        main.post {
            Toast.makeText(app, "পাঠানো যায়নি", Toast.LENGTH_SHORT).show()
        }
    }

    private val store get() = (app.applicationContext as KothaApp).settings

    private data class ReplySlot(
        val notification: Notification,
        val packageName: String,
        val key: String,
    )
}
