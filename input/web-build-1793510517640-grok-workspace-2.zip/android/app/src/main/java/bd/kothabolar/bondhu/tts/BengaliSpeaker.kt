package bd.kothabolar.bondhu.tts

import android.content.Context
import android.media.AudioAttributes
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import bd.kothabolar.bondhu.KothaLog
import java.util.Locale

class BengaliSpeaker(
    context: Context,
    private val onUtteranceDone: (String) -> Unit,
    private val onLanguageMissing: () -> Unit,
) : TextToSpeech.OnInitListener {
    private val tts = TextToSpeech(context.applicationContext, this)
    private var ready = false
    private var failed = false
    private var pending: Pair<String, String>? = null
    private var rate = 0.9f

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            failed = true
            KothaLog.w("tts-init")
            flushPendingAsDone()
            return
        }
        tts.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build(),
        )
        val primary = tts.setLanguage(Locale("bn", "BD"))
        val missing = primary == TextToSpeech.LANG_MISSING_DATA || primary == TextToSpeech.LANG_NOT_SUPPORTED
        if (missing) {
            val fallback = tts.setLanguage(Locale("bn"))
            val stillMissing = fallback == TextToSpeech.LANG_MISSING_DATA || fallback == TextToSpeech.LANG_NOT_SUPPORTED
            if (stillMissing) {
                failed = true
                KothaLog.w("tts-bn-missing")
                onLanguageMissing()
                flushPendingAsDone()
                return
            }
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit

            override fun onDone(utteranceId: String?) {
                utteranceId?.let(onUtteranceDone)
            }

            @Deprecated("legacy")
            override fun onError(utteranceId: String?) {
                utteranceId?.let(onUtteranceDone)
            }
        })
        ready = true
        pending?.let { (id, text) ->
            pending = null
            speakNow(id, text)
        }
    }

    fun speak(id: String, text: String, speechRate: Float) {
        rate = speechRate
        if (failed) {
            onUtteranceDone(id)
            return
        }
        if (!ready) {
            val previous = pending
            pending = id to text
            if (previous != null && previous.first != id) onUtteranceDone(previous.first)
            return
        }
        speakNow(id, text)
    }

    fun stop() {
        pending = null
        runCatching { tts.stop() }
    }

    fun shutdown() {
        pending = null
        runCatching { tts.shutdown() }
    }

    private fun speakNow(id: String, text: String) {
        tts.setSpeechRate(rate)
        val params = Bundle()
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, id)
        val queued = tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, id)
        if (queued == TextToSpeech.ERROR) {
            KothaLog.w("tts-speak")
            onUtteranceDone(id)
        }
    }

    private fun flushPendingAsDone() {
        pending?.first?.let(onUtteranceDone)
        pending = null
    }
}
