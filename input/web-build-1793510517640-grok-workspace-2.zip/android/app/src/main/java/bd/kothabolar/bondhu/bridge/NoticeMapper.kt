package bd.kothabolar.bondhu.bridge

import android.app.Notification
import android.os.Build
import android.os.Bundle
import android.service.notification.StatusBarNotification
import bd.kothabolar.bondhu.domain.NoticeCategory
import bd.kothabolar.bondhu.domain.NoticeMessage
import bd.kothabolar.bondhu.domain.RawNotice

object NoticeMapper {
    fun map(sbn: StatusBarNotification): RawNotice {
        val n = sbn.notification
        val extras = n.extras ?: Bundle()
        val style = Notification.MessagingStyle.extractMessagingStyleFromNotification(n)
        val selfKey = if (Build.VERSION.SDK_INT >= 28) style?.user?.key else null
        val messages = style?.messages.orEmpty().map { msg ->
            val sender = senderName(msg)
            val personKey = if (Build.VERSION.SDK_INT >= 28) msg.person?.key else null
            val mime = if (Build.VERSION.SDK_INT >= 28) msg.dataMimeType else null
            val self = (selfKey != null && selfKey == personKey) ||
                sender.equals("you", ignoreCase = true) || sender == "আপনি"
            NoticeMessage(
                sender = sender,
                text = msg.text?.toString().orEmpty(),
                timestamp = msg.timestamp,
                mime = mime,
                isSelf = self,
            )
        }
        val audio = audioUri(style, messages)
        val groupFlag = if (Build.VERSION.SDK_INT >= 28) {
            extras.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false) || style?.isGroupConversation == true
        } else {
            false
        }
        return RawNotice(
            key = sbn.key,
            packageName = sbn.packageName,
            postedAt = sbn.postTime,
            title = extras.charOf(Notification.EXTRA_TITLE).ifEmpty { n.tickerText?.toString().orEmpty() },
            text = extras.charOf(Notification.EXTRA_TEXT),
            bigText = extras.charOf(Notification.EXTRA_BIG_TEXT),
            conversationTitle = extras.charOf(Notification.EXTRA_CONVERSATION_TITLE).ifBlank { null },
            isGroupConversation = groupFlag,
            isGroupSummary = n.flags and Notification.FLAG_GROUP_SUMMARY != 0,
            category = categoryOf(n, style != null),
            messagingStyle = style != null,
            messages = messages,
            hasReplyAction = hasReply(n),
            audioUri = audio,
            channelId = if (Build.VERSION.SDK_INT >= 26) n.channelId else null,
        )
    }

    private fun senderName(msg: Notification.MessagingStyle.Message): String {
        return if (Build.VERSION.SDK_INT >= 28) {
            msg.person?.name?.toString().orEmpty()
        } else {
            @Suppress("DEPRECATION")
            msg.sender?.toString().orEmpty()
        }
    }

    private fun audioUri(
        style: Notification.MessagingStyle?,
        messages: List<NoticeMessage>,
    ): String? {
        if (style == null || Build.VERSION.SDK_INT < 28) return null
        val hit = style.messages.lastOrNull { message ->
            val mime = message.dataMimeType
            message.dataUri != null && mime != null && mime.startsWith("audio/")
        }
        return hit?.dataUri?.toString()
    }

    private fun hasReply(n: Notification): Boolean {
        val actions = n.actions ?: return false
        if (Build.VERSION.SDK_INT >= 28) {
            val semantic = actions.any {
                it.semanticAction == Notification.Action.SEMANTIC_ACTION_REPLY &&
                    it.remoteInputs?.any { input -> input.allowFreeFormInput && !input.isDataOnly } == true
            }
            if (semantic) return true
        }
        return actions.any { action ->
            action.remoteInputs?.any { it.allowFreeFormInput && !it.isDataOnly } == true
        }
    }

    private fun categoryOf(n: Notification, messaging: Boolean): NoticeCategory {
        return when (n.category) {
            Notification.CATEGORY_CALL -> NoticeCategory.CALL
            Notification.CATEGORY_MISSED_CALL -> NoticeCategory.MISSED_CALL
            Notification.CATEGORY_MESSAGE -> NoticeCategory.MESSAGE
            Notification.CATEGORY_PROGRESS -> NoticeCategory.PROGRESS
            Notification.CATEGORY_STATUS -> NoticeCategory.STATUS
            else -> if (messaging) NoticeCategory.MESSAGE else NoticeCategory.OTHER
        }
    }

    private fun Bundle.charOf(key: String): String = getCharSequence(key)?.toString()?.trim().orEmpty()
}
