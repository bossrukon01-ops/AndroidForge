package bd.kothabolar.bondhu.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.speech.tts.TextToSpeech
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import bd.kothabolar.bondhu.KothaApp
import bd.kothabolar.bondhu.bridge.UiStatus
import bd.kothabolar.bondhu.domain.TargetApps
import bd.kothabolar.bondhu.service.KothaNotifications

private val Paper = Color(0xFFF3ECDF)
private val Ink = Color(0xFF1C1915)
private val Green = Color(0xFF1F6B4A)
private val Muted = Color(0xFF6E675E)
private val Warn = Color(0xFFC45C26)
private val Card = Color(0xFFFFFAF3)

@Composable
fun KothaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            onPrimary = Color(0xFFFFFAF3),
            background = Paper,
            onBackground = Ink,
            surface = Card,
            onSurface = Ink,
        ),
        content = content,
    )
}

@Composable
fun KothaRoot() {
    val context = LocalContext.current
    val app = context.applicationContext as KothaApp
    val lifecycleOwner = LocalLifecycleOwner.current
    var listenerOn by remember { mutableStateOf(KothaNotifications.listenerEnabled(context)) }
    var micOn by remember { mutableStateOf(hasMic(context)) }
    var postsOn by remember { mutableStateOf(canPost(context)) }
    var batteryOn by remember { mutableStateOf(ignoresBattery(context)) }
    var enabled by remember { mutableStateOf(app.settings.enabled) }
    var readAloud by remember { mutableStateOf(app.settings.readAloud) }
    var voiceReply by remember { mutableStateOf(app.settings.voiceReply) }
    var voiceNotes by remember { mutableStateOf(app.settings.playVoiceNotes) }
    var aliases by remember { mutableStateOf(app.settings.aliases.joinToString(", ")) }
    var packages by remember { mutableStateOf(app.settings.packages) }
    var rate by remember { mutableStateOf(app.settings.speechRate) }
    var status by remember { mutableStateOf(app.runtime.status) }

    DisposableEffect(app) {
        val listener: (UiStatus) -> Unit = { status = it }
        app.runtime.addStatusListener(listener)
        onDispose { app.runtime.removeStatusListener(listener) }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                listenerOn = KothaNotifications.listenerEnabled(context)
                micOn = hasMic(context)
                postsOn = canPost(context)
                batteryOn = ignoresBattery(context)
                enabled = app.settings.enabled
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        micOn = hasMic(context)
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        postsOn = canPost(context)
    }

    Scaffold(containerColor = Paper) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("কথাবলার বন্ধু", fontSize = 34.sp, fontWeight = FontWeight.SemiBold, color = Ink, lineHeight = 40.sp)
            Text(
                "হোয়াটসঅ্যাপ, মেসেঞ্জার, টেলিগ্রাম। মানুষের কথা পড়ে। নিজে উত্তর বানায় না।",
                fontSize = 18.sp,
                color = Muted,
                lineHeight = 26.sp,
            )

            StatusCard(status, enabled, listenerOn)

            val pending = status.pendingText
            if (pending != null) {
                ConfirmCard(
                    destination = status.pendingDestination ?: status.pendingSender.orEmpty(),
                    group = status.pendingGroup,
                    text = pending,
                    onSend = { app.runtime.acceptPending() },
                    onCancel = { app.runtime.rejectPending() },
                )
            }

            Text(context.getString(bd.kothabolar.bondhu.R.string.disclosure), fontSize = 16.sp, color = Ink, lineHeight = 24.sp)

            SectionTitle("অনুমতি")
            BigButton("নোটিফিকেশন অ্যাক্সেস ${mark(listenerOn)}") {
                context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
            Hint("কেন: হোয়াটসঅ্যাপ, মেসেঞ্জার, টেলিগ্রামের আসা বার্তা পড়তে। লেখা ফোনের বাইরে যায় না।")
            BigButton("মাইক্রোফোন ${mark(micOn)}") {
                micLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
            Hint("কেন: আপনি উত্তর বললে সেটি লেখা করতে। বার্তা পড়ার সময় শুধু থামানোর কথা শোনে। নইলে মাইক বন্ধ।")
            if (Build.VERSION.SDK_INT >= 33) {
                BigButton("নিজের নোটিফিকেশন ${mark(postsOn)}") {
                    notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                Hint("কেন: উত্তরের লেখা লক স্ক্রিনে দেখিয়ে পাঠাব কি না জিজ্ঞাসা করতে।")
            }
            BigButton("ব্যাটারি ছাড় ${mark(batteryOn)}") {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:${context.packageName}")
                }
                runCatching { context.startActivity(intent) }
            }
            Hint("কেন: কিছু ফোন লক থাকলে অ্যাপ মেরে ফেলে। একবার ছাড় দিলে শোনা চালু থাকে।")
            BigButton("বাংলা কণ্ঠস্বর বসান") {
                runCatching { context.startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)) }
            }
            Hint("ফোনে বাংলা (বাংলাদেশ) কণ্ঠ না থাকলে পড়া হবে না। ইংরেজি কণ্ঠ দিয়ে ভান করা হয় না।")
            if (status.ttsMissing) {
                Text("বাংলা কণ্ঠ পাওয়া যায়নি। উপরের বোতামে ডাউনলোড করুন।", color = Warn, fontSize = 16.sp)
            }

            SectionTitle("গ্রুপে যে নামে ডাকে")
            OutlinedTextField(
                value = aliases,
                onValueChange = { value ->
                    aliases = value
                    app.settings.aliases = value.split(",", "\n").map { it.trim() }
                },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("রহিম, Rahim, @rahim") },
                textStyle = MaterialTheme.typography.bodyLarge.copy(fontSize = 20.sp),
            )
            Hint("খালি থাকলে গ্রুপ পড়া হয় না। সরাসরি চ্যাট পড়া হয়। রহিম আর রহিমা আলাদা।")

            SectionTitle("যে অ্যাপ শুনবে")
            TargetApps.packages.forEach { (pkg, label) ->
                ToggleRow(label, pkg in packages) { on ->
                    val next = packages.toMutableSet()
                    if (on) next.add(pkg) else next.remove(pkg)
                    packages = next
                    app.settings.packages = next
                }
            }

            SectionTitle("কী কী চালু")
            ToggleRow("বার্তা জোরে পড়া", readAloud) {
                readAloud = it
                app.settings.readAloud = it
            }
            ToggleRow("ভয়েস নোট বাজানো", voiceNotes) {
                voiceNotes = it
                app.settings.playVoiceNotes = it
            }
            Hint("ফাইল না পেলে শুধু বলে: একটি ভয়েস বার্তা। অ্যাপ বন্ধ হয় না।")
            ToggleRow("কথায় উত্তর", voiceReply) {
                voiceReply = it
                app.settings.voiceReply = it
            }
            Hint("বন্ধ থাকলে বার্তা পড়ে, কিন্তু উত্তরের জন্য মাইক খোলে না।")

            Text("পড়ার গতি", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Ink)
            Slider(
                value = rate,
                onValueChange = { value ->
                    rate = value
                    app.settings.speechRate = value
                },
                valueRange = 0.7f..1.2f,
            )
            Hint(if (rate < 0.85f) "একটু ধীরে" else if (rate > 1.05f) "একটু জোরে" else "স্বাভাবিক")

            SectionTitle(if (enabled) "চালু আছে" else "বন্ধ আছে")
            BigButton(if (enabled) "বন্ধ করুন" else "চালু করুন") {
                val want = !enabled
                if (want && !listenerOn) return@BigButton
                enabled = want
                app.settings.enabled = want
            }
            if (!listenerOn) {
                Text("আগে নোটিফিকেশন অ্যাক্সেস দিন, তারপর চালু করুন।", color = Warn, fontSize = 16.sp)
            }
            BigButton("কণ্ঠ পরীক্ষা") { app.runtime.speakSample() }

            SectionTitle("কীভাবে চলে")
            Hint("১. উপরের অনুমতি দিন, নাম সেভ করুন, চালু করুন।")
            Hint("২. কেউ সরাসরি চ্যাটে লিখলে ফোন বলে: নাম বলছে, তারপর কথা।")
            Hint("৩. গ্রুপ শুধু তখন, যখন আপনার নাম বা @ট্যাগ থাকে।")
            Hint("৪. উত্তর বলুন। লেখা দেখাবে। হ্যাঁ বললে বা পাঠাও চাপলে সেই চ্যাটে যায়।")
            Hint("৫. না বললে বা বাতিল চাপলে কিছু যায় না। পড়ার সময় স্টপ, থামো, বা চুপ করো বললে সব থামে।")
            Hint("৬. রিপ্লাই বোতাম না থাকলে ফোন বলে দেবে যে পাঠানো যাচ্ছে না।")
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun StatusCard(status: UiStatus, enabled: Boolean, listenerOn: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Card, RoundedCornerShape(20.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(
            when {
                !listenerOn -> "নোটিফিকেশন অ্যাক্সেস নেই"
                !enabled -> "বন্ধ আছে"
                else -> status.phase
            },
            fontSize = 26.sp,
            fontWeight = FontWeight.SemiBold,
            color = Ink,
        )
        val who = status.speakingSender
        if (enabled && listenerOn && who != null && status.pendingText == null) {
            Text("এখন: $who", fontSize = 18.sp, color = Ink)
        }
        Text(status.detail, fontSize = 16.sp, color = Muted, lineHeight = 22.sp)
    }
}

@Composable
private fun ConfirmCard(
    destination: String,
    group: Boolean,
    text: String,
    onSend: () -> Unit,
    onCancel: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFFFF1E4), RoundedCornerShape(20.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(if (group) "এই গ্রুপে যাবে" else "এই মানুষকে যাবে", color = Warn, fontSize = 16.sp)
        Text(destination, fontSize = 28.sp, fontWeight = FontWeight.SemiBold, color = Ink)
        Text("আপনি বললেন", color = Muted, fontSize = 16.sp)
        Text(text, fontSize = 24.sp, color = Ink, lineHeight = 32.sp)
        BigButton("পাঠাও", onClick = onSend)
        BigButton("বাতিল", filled = false, onClick = onCancel)
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = Ink)
}

@Composable
private fun Hint(text: String) {
    Text(text, color = Muted, fontSize = 15.sp, lineHeight = 22.sp)
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().height(56.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, modifier = Modifier.weight(1f), fontSize = 18.sp, color = Ink)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun BigButton(label: String, filled: Boolean = true, onClick: () -> Unit) {
    if (filled) {
        Button(
            onClick = onClick,
            modifier = Modifier.fillMaxWidth().height(60.dp),
            shape = RoundedCornerShape(28.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color(0xFFFFFAF3)),
        ) {
            Text(label, fontSize = 18.sp)
        }
    } else {
        OutlinedButton(
            onClick = onClick,
            modifier = Modifier.fillMaxWidth().height(60.dp),
            shape = RoundedCornerShape(28.dp),
        ) {
            Text(label, fontSize = 18.sp, color = Ink)
        }
    }
}

private fun mark(on: Boolean): String = if (on) "দেওয়া আছে" else "দিন"

private fun hasMic(context: android.content.Context): Boolean =
    ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
        PackageManager.PERMISSION_GRANTED

private fun canPost(context: android.content.Context): Boolean {
    if (Build.VERSION.SDK_INT < 33) return true
    return ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
        PackageManager.PERMISSION_GRANTED
}

private fun ignoresBattery(context: android.content.Context): Boolean {
    val pm = context.getSystemService(PowerManager::class.java) ?: return false
    return pm.isIgnoringBatteryOptimizations(context.packageName)
}
