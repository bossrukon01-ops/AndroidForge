package bd.kothabolar.bondhu.reply

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle

object DirectReplySender {
    const val MAX_CHARS = 500

    sealed interface Result {
        data object Sent : Result
        data object Empty : Result
        data object NoAction : Result
        data object Canceled : Result
        data class Failed(val reason: String) : Result
    }

    fun send(context: Context, notification: Notification, text: String): Result {
        val body = text.trim()
        if (body.isEmpty()) return Result.Empty
        val clipped = body.take(MAX_CHARS)
        val action = pick(notification) ?: return Result.NoAction
        val inputs = action.remoteInputs?.filter { it.allowFreeFormInput && !it.isDataOnly }.orEmpty()
        if (inputs.isEmpty()) return Result.NoAction
        val fill = Intent()
        val bundle = Bundle()
        for (input in inputs) bundle.putCharSequence(input.resultKey, clipped)
        RemoteInput.addResultsToIntent(inputs.toTypedArray(), fill, bundle)
        return try {
            action.actionIntent.send(context, 0, fill)
            Result.Sent
        } catch (_: PendingIntent.CanceledException) {
            Result.Canceled
        } catch (error: Exception) {
            Result.Failed(error.javaClass.simpleName)
        }
    }

    private fun pick(notification: Notification): Notification.Action? {
        val actions = notification.actions ?: return null
        if (Build.VERSION.SDK_INT >= 28) {
            actions.firstOrNull { action ->
                action.semanticAction == Notification.Action.SEMANTIC_ACTION_REPLY && hasFreeForm(action)
            }?.let { return it }
        }
        return actions.firstOrNull { hasFreeForm(it) }
    }

    private fun hasFreeForm(action: Notification.Action): Boolean =
        action.remoteInputs?.any { it.allowFreeFormInput && !it.isDataOnly } == true
}
