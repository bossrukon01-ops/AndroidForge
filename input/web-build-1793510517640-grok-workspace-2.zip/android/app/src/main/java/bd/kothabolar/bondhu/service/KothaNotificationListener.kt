package bd.kothabolar.bondhu.service

import android.content.ComponentName
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import bd.kothabolar.bondhu.KothaApp

class KothaNotificationListener : NotificationListenerService() {
    private val runtime get() = (application as KothaApp).runtime

    override fun onListenerConnected() {
        runtime.seed(activeNotifications?.toList().orEmpty())
    }

    override fun onListenerDisconnected() {
        if (Build.VERSION.SDK_INT >= 24) {
            requestRebind(ComponentName(this, javaClass))
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        runtime.onPosted(sbn)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        runtime.onRemoved(sbn.key)
    }
}
