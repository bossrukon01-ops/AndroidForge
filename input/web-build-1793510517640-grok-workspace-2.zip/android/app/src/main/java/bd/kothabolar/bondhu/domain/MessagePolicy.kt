package bd.kothabolar.bondhu.domain

private const val STALE_MS = 20_000L
private const val ECHO_MS = 30_000L

private val voiceHint = Regex("voice message|voice note|audio message|ভয়েস|ভয়েস|অডিও বার্তা|🎤", RegexOption.IGNORE_CASE)
private val reactionHint = Regex("\\breacted\\b|reaction to|প্রতিক্রিয়া জানিয়েছে|রিঅ্যাক্ট করেছে", RegexOption.IGNORE_CASE)
private val deletedHint = Regex("this message was deleted|message was deleted|deleted this message|বার্তাটি মুছে|মেসেজ ডিলিট|মুছে ফেলেছে", RegexOption.IGNORE_CASE)
private val typingHint = Regex("typing…|typing\\.\\.\\.|is typing|টাইপ করছে|লিখছেন|লিখছে", RegexOption.IGNORE_CASE)
private val callChannel = Regex("call|voip|ringtone", RegexOption.IGNORE_CASE)
private val callHint = Regex(
    "missed call|incoming call|voice call|video call|is calling|calling you|মিসড কল|ইনকামিং কল|ভয়েস কল|ভিডিও কল|কল করেছেন",
    RegexOption.IGNORE_CASE,
)
private val noiseExact = setOf(
    "online", "offline", "অনলাইন", "অফলাইন",
    "checking for new messages", "checking for messages",
    "backup in progress", "ব্যাকআপ চলছে", "বার্তা দেখা হচ্ছে",
    "new status", "নতুন স্ট্যাটাস",
)
private val genericTitles = setOf(
    "whatsapp", "messenger", "telegram",
    "হোয়াটসঅ্যাপ", "মেসেঞ্জার", "টেলিগ্রাম",
)

fun conversationId(notice: RawNotice): String {
    val title = (notice.conversationTitle ?: notice.title).trim()
    return "${notice.packageName}::${title.ifEmpty { notice.key }}"
}

fun summaryHoldHash(notice: RawNotice): String =
    textHash(listOf(notice.packageName, conversationId(notice), bodyOf(notice).trim()))

fun dedupeKey(notice: RawNotice): String {
    val newest = newestMessage(notice)
    val stamp = newest?.timestamp ?: notice.postedAt
    return "${notice.packageName}|${notice.key}|$stamp|${textHash(listOf(bodyOf(notice)))}"
}

fun evaluate(notice: RawNotice, settings: PolicySettings, seen: Set<String>): Decision {
    val pkg = notice.packageName
    if (pkg !in TargetApps.packages) {
        return Decision.Ignore("R-PACKAGE", "টার্গেট অ্যাপ নয়।")
    }
    if (pkg !in settings.enabledPackages) {
        return Decision.Ignore("R-APP-OFF", "এই অ্যাপটি বন্ধ।")
    }
    if (!settings.readAloud) {
        return Decision.Ignore("R-MUTE", "জোরে পড়া বন্ধ আছে।")
    }
    if (notice.fromInitialSnapshot) {
        return Decision.Ignore("R-SNAPSHOT", "বাঁধার সময়ের পুরনো নোটিফিকেশন।")
    }
    if (settings.now - notice.postedAt > STALE_MS) {
        return Decision.Ignore("R-STALE", "২০ সেকেন্ডের বেশি পুরনো।")
    }
    if (notice.channelId != null && callChannel.containsMatchIn(notice.channelId)) {
        return Decision.Ignore("R-CHANNEL", "কল চ্যানেল।")
    }
    if (notice.category == NoticeCategory.CALL || notice.category == NoticeCategory.MISSED_CALL) {
        return Decision.Ignore("R-CATEGORY", "কল পড়া হয় না।")
    }
    if (notice.category == NoticeCategory.PROGRESS || notice.category == NoticeCategory.STATUS) {
        return Decision.Ignore("R-CATEGORY", "স্ট্যাটাস বা প্রগ্রেস।")
    }
    if (notice.category != NoticeCategory.MESSAGE && !notice.messagingStyle) {
        val preview = bodyOf(notice).trim()
        val audioMime = notice.messages.any { it.mime?.startsWith("audio/") == true }
        val hasContent = preview.isNotEmpty() || audioMime || !notice.audioUri.isNullOrBlank()
        if (!hasContent) return Decision.Ignore("R-CATEGORY", "মেসেজ নয়।")
    }

    val rawBody = bodyOf(notice).trim()
    val norm = normalize(rawBody)
    val audioMime = notice.messages.any { it.mime?.startsWith("audio/") == true }
    if (callHint.containsMatchIn(notice.title) || callHint.containsMatchIn(rawBody)) {
        return Decision.Ignore("R-CALL-TEXT", "কলের বার্তা।")
    }
    if (!notice.messagingStyle && notice.messages.isEmpty() && normalize(notice.title) in genericTitles) {
        return Decision.Ignore("R-NOISE", "অ্যাপের সাধারণ নোটিফিকেশন।")
    }
    if (rawBody.isEmpty() && !audioMime && notice.audioUri.isNullOrBlank()) {
        return Decision.Ignore("R-EMPTY", "খালি বার্তা।")
    }
    if (deletedHint.containsMatchIn(rawBody)) return Decision.Ignore("R-DELETED", "মুছে ফেলা বার্তা।")
    if (reactionHint.containsMatchIn(rawBody)) return Decision.Ignore("R-REACTION", "রিঅ্যাকশন।")
    if (typingHint.containsMatchIn(rawBody) || norm in noiseExact) {
        return Decision.Ignore("R-NOISE", "টাইপিং বা স্ট্যাটাস।")
    }
    val key = dedupeKey(notice)
    if (key in seen) return Decision.Ignore("R-DUPLICATE", "আগেই প্রসেস হয়েছে।")

    val newest = newestMessage(notice)
    if (newest?.isSelf == true) return Decision.Ignore("R-SELF", "নিজের বার্তা।")

    val conv = conversationId(notice)
    val stripped = stripSenderPrefix(rawBody, newest?.sender.orEmpty())
    val echo = settings.recentReplies.any {
        it.conversationId == conv && settings.now - it.at < ECHO_MS && normalize(it.text) == normalize(stripped)
    }
    if (echo) return Decision.Ignore("R-ECHO", "এইমাত্র পাঠানো উত্তর।")

    if (notice.isGroupSummary) {
        return Decision.DeferSummary(summaryHoldHash(notice), "সারাংশ আটকে রাখা হয়েছে।")
    }

    val grouped = explicitGroup(notice)
    val ambiguous = !grouped && ambiguousGroup(notice)
    val groupLike = grouped || ambiguous
    val sender = senderOf(notice, groupLike)
    var body = sanitizeBody(stripSenderPrefix(rawBody, sender))
    if (body.isEmpty() && (!notice.audioUri.isNullOrBlank() || audioMime)) body = "একটি ভয়েস বার্তা"
    if (body.isEmpty()) return Decision.Ignore("R-EMPTY", "পড়ার মতো লেখা নেই।")

    if (groupLike) {
        val aliases = settings.aliases.filter { normalize(it).length >= 2 }
        if (aliases.isEmpty()) return Decision.Ignore("R-GROUP-NO-ALIAS", "গ্রুপের জন্য নাম সেট নেই।")
        val hay = "${notice.title}\n${notice.conversationTitle.orEmpty()}\n$rawBody"
        if (!mentioned(hay, aliases)) {
            val rule = if (ambiguous && !grouped) "R-AMBIGUOUS-GROUP" else "R-GROUP-NO-MENTION"
            return Decision.Ignore(rule, "গ্রুপে নাম বা ট্যাগ নেই।")
        }
    }

    val label = TargetApps.label(pkg)
    val voiceUri = notice.audioUri?.takeIf { it.isNotBlank() }
    val voice = voiceHint.containsMatchIn(rawBody) || audioMime || voiceUri != null
    if (voice && voiceUri != null && settings.playVoiceNotes) {
        return Decision.PlayVoice(sender, body, conv, notice.hasReplyAction, label, pkg, voiceUri, groupLike)
    }
    if (voice) {
        return Decision.AnnounceVoice(
            sender, "একটি ভয়েস বার্তা", formatSpeech(sender, "একটি ভয়েস বার্তা"),
            conv, notice.hasReplyAction, label, pkg, groupLike,
        )
    }
    return Decision.Speak(
        if (groupLike) "R-MENTION" else "R-DM",
        sender, body, formatSpeech(sender, body), conv, notice.hasReplyAction, label, pkg, groupLike,
    )
}

private fun newestMessage(notice: RawNotice): NoticeMessage? =
    notice.messages.maxByOrNull { it.timestamp }

private fun bodyOf(notice: RawNotice): String {
    val newest = newestMessage(notice)
    if (!newest?.text.isNullOrBlank()) return newest!!.text
    if (notice.bigText.isNotBlank()) return notice.bigText
    return notice.text
}

private fun explicitGroup(notice: RawNotice): Boolean {
    if (notice.isGroupConversation) return true
    val senders = notice.messages.filter { !it.isSelf && it.sender.isNotBlank() }.map { normalize(it.sender) }.toSet()
    return senders.size >= 2
}

private fun ambiguousGroup(notice: RawNotice): Boolean {
    val match = Regex("^([^:]{1,40}):\\s+(\\S[\\s\\S]*)$").find(bodyOf(notice)) ?: return false
    val prefix = normalize(match.groupValues[1])
    val title = normalize(notice.title)
    if (prefix.isEmpty() || prefix == title) return false
    if (prefix == "you" || prefix == "আপনি") return false
    return true
}

private fun senderOf(notice: RawNotice, grouped: Boolean): String {
    val newest = newestMessage(notice)
    if (!newest?.sender.isNullOrBlank() && newest?.isSelf != true) return newest!!.sender.trim()
    if (!grouped && notice.title.isNotBlank()) return notice.title.trim()
    val prefixed = Regex("^([^:]{1,40}):\\s+\\S").find(bodyOf(notice))
    if (prefixed != null && grouped) return prefixed.groupValues[1].trim()
    return notice.title.trim().ifEmpty { TargetApps.label(notice.packageName) }
}

private fun stripSenderPrefix(body: String, sender: String): String {
    if (sender.isBlank()) return body.trim()
    return body.replace(Regex("^${Regex.escape(sender)}\\s*:\\s*", RegexOption.IGNORE_CASE), "").trim()
}
