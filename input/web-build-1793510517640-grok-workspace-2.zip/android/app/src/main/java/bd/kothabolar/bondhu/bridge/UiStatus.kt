package bd.kothabolar.bondhu.bridge

/** On-screen status. Pending text exists only until the reply is sent or dropped. */
data class UiStatus(
    val phase: String = "ঘুমাচ্ছে",
    val detail: String = "নোটিফিকেশনের অপেক্ষায়।",
    val pendingSender: String? = null,
    val pendingText: String? = null,
    val pendingDestination: String? = null,
    val pendingGroup: Boolean = false,
    val speakingSender: String? = null,
    val ttsMissing: Boolean = false,
)
