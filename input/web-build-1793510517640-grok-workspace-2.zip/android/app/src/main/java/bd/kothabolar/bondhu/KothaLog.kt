package bd.kothabolar.bondhu

import android.util.Log

/** Never log message bodies. Rule ids only. */
object KothaLog {
    fun i(rule: String) {
        Log.i(TAG, rule)
    }

    fun w(rule: String, error: Throwable? = null) {
        if (error == null) Log.w(TAG, rule) else Log.w(TAG, rule, error)
    }

    private const val TAG = "Kotha"
}
