package bd.kothabolar.bondhu.data

import android.content.Context
import bd.kothabolar.bondhu.domain.PolicySettings
import bd.kothabolar.bondhu.domain.TargetApps

class SettingsStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("kotha", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = prefs.getBoolean(KEY_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_ENABLED, value).apply()

    var readAloud: Boolean
        get() = prefs.getBoolean(KEY_READ, true)
        set(value) = prefs.edit().putBoolean(KEY_READ, value).apply()

    var voiceReply: Boolean
        get() = prefs.getBoolean(KEY_REPLY, true)
        set(value) = prefs.edit().putBoolean(KEY_REPLY, value).apply()

    var playVoiceNotes: Boolean
        get() = prefs.getBoolean(KEY_NOTES, true)
        set(value) = prefs.edit().putBoolean(KEY_NOTES, value).apply()

    var speechRate: Float
        get() = prefs.getFloat(KEY_RATE, 0.9f).coerceIn(0.7f, 1.2f)
        set(value) = prefs.edit().putFloat(KEY_RATE, value.coerceIn(0.7f, 1.2f)).apply()

    var aliases: List<String>
        get() = prefs.getString(KEY_ALIASES, "").orEmpty()
            .split("\n")
            .map { it.trim() }
            .filter { it.length >= 2 }
        set(value) = prefs.edit().putString(
            KEY_ALIASES,
            value.map { it.trim() }.filter { it.length >= 2 }.joinToString("\n"),
        ).apply()

    var packages: Set<String>
        get() {
            val saved = prefs.getStringSet(KEY_PACKAGES, null)
            return saved?.intersect(TargetApps.packages.keys) ?: TargetApps.packages.keys
        }
        set(value) {
            // SharedPreferences keeps the same StringSet instance. Always copy.
            val copy = HashSet(value.intersect(TargetApps.packages.keys))
            prefs.edit().putStringSet(KEY_PACKAGES, copy).apply()
        }

    fun snapshot(now: Long): PolicySettings = PolicySettings(
        aliases = aliases,
        enabledPackages = packages,
        now = now,
        recentReplies = emptyList(),
        readAloud = readAloud,
        voiceReply = voiceReply,
        playVoiceNotes = playVoiceNotes,
    )

    private companion object {
        const val KEY_ENABLED = "enabled"
        const val KEY_READ = "readAloud"
        const val KEY_REPLY = "voiceReply"
        const val KEY_NOTES = "voiceNotes"
        const val KEY_RATE = "rate"
        const val KEY_ALIASES = "aliases"
        const val KEY_PACKAGES = "packages"
    }
}
