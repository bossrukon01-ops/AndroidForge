package bd.kothabolar.bondhu.util

import android.content.Context
import android.os.PowerManager
import android.os.SystemClock

/** Partial wake lock, hard-capped, never held while the session is asleep. */
class SafeWakeLock(context: Context) {
    private val lock = (context.applicationContext.getSystemService(Context.POWER_SERVICE) as PowerManager)
        .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "kothabolar:session")
        .apply { setReferenceCounted(false) }

    private var acquiredAt = 0L

    fun acquire() {
        val heldFor = SystemClock.elapsedRealtime() - acquiredAt
        if (lock.isHeld && heldFor < MAX_HOLD_MS) return
        if (lock.isHeld) lock.release()
        lock.acquire(MAX_HOLD_MS)
        acquiredAt = SystemClock.elapsedRealtime()
    }

    fun release() {
        if (lock.isHeld) lock.release()
        acquiredAt = 0L
    }

    private companion object {
        const val MAX_HOLD_MS = 60_000L
    }
}
