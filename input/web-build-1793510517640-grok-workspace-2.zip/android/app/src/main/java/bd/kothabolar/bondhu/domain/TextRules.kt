package bd.kothabolar.bondhu.domain

private val boundary = Regex("""[\s.,!?:;@#()\[\]{}<>"'«»…|/\\*_~*।\-]""")

fun normalize(input: String): String =
    input.replace(Regex("[\\u200B-\\u200D\\uFEFF]"), "").replace(Regex("\\s+"), " ").trim().lowercase()

fun textHash(parts: List<String>): String {
    val s = normalize(parts.joinToString("|"))
    var h = 2166136261u
    for (ch in s) {
        h = h xor ch.code.toUInt()
        h *= 16777619u
    }
    return h.toString(16)
}

fun containsBounded(haystack: String, needle: String): Boolean {
    if (needle.length < 2) return false
    val hay = normalize(haystack)
    val n = normalize(needle)
    if (n.length < 2) return false
    var from = 0
    while (from <= hay.length - n.length) {
        val i = hay.indexOf(n, from)
        if (i < 0) return false
        val before = if (i == 0) " " else hay.substring(i - 1, i)
        val after = if (i + n.length >= hay.length) " " else hay.substring(i + n.length, i + n.length + 1)
        if (isBoundary(before) && isBoundary(after)) return true
        from = i + 1
    }
    return false
}

private fun isBoundary(ch: String): Boolean = ch == " " || boundary.matches(ch)

fun mentioned(text: String, aliases: List<String>): Boolean {
    val usable = aliases.map { it.trim() }.filter { normalize(it).length >= 2 }
    if (usable.isEmpty()) return false
    return usable.any { alias ->
        containsBounded(text, alias) ||
            containsBounded(text, alias.trimStart('@')) ||
            containsBounded(text, "@${alias.trimStart('@')}")
    }
}

fun sanitizeBody(raw: String): String {
    val stripped = buildString {
        val cleaned = raw.replace(Regex("[\\u200B-\\u200D\\uFEFF]"), "")
            .replace(Regex("https?://\\S+", RegexOption.IGNORE_CASE), "একটি লিংক")
        var i = 0
        while (i < cleaned.length) {
            val cp = cleaned.codePointAt(i)
            val emoji = cp in 0x1F000..0x1FAFF || cp in 0x2600..0x27BF || cp == 0xFE0F || cp == 0x200D
            if (!emoji) appendCodePoint(cp)
            i += Character.charCount(cp)
        }
    }.replace(Regex("\\s+"), " ").trim()
    if (stripped.isEmpty()) return ""
    if (stripped.length <= 280) return stripped
    return stripped.take(279).trim() + "…"
}

fun formatSpeech(sender: String, body: String): String = "$sender বলছে: $body"

private val stopPhrases = listOf("চুপ করো", "চুপ কর", "থামো", "থামুন", "থাম", "স্টপ", "stop", "thamo", "chup koro", "chup")
private val stopFillers = listOf("প্লিজ", "please", "দাদা", "আপা", "এখন", "ভাই", "আচ্ছা", "ok")

fun isNegatedStop(transcript: String): Boolean {
    val n = normalize(transcript)
    return n.contains("থামো না") || n.contains("থামুন না") || n.contains("থাম না") ||
        n.contains("চুপ করো না") || n.contains("চুপ কর না") ||
        n.contains("thamo na") || n.contains("chup koro na") ||
        n.contains("don't stop") || n.contains("dont stop")
}

/**
 * Stop only when the whole utterance is a stop phrase, plus optional polite fillers.
 * "থামো না" and any longer sentence stay a reply so we never throw away real speech.
 */
fun isStopCommand(transcript: String): Boolean {
    val n = normalize(transcript)
    if (n.isEmpty() || isNegatedStop(n)) return false
    var stripped = n
    for (filler in stopFillers) {
        stripped = stripped.replace(filler, " ")
    }
    stripped = stripped.replace(Regex("[।,!?.…]+"), " ").replace(Regex("\\s+"), " ").trim()
    if (stripped.isEmpty()) return false
    return stopPhrases.any { normalize(it) == stripped }
}

enum class UtteranceKind { EMPTY, STOP, REPLY }

fun classifyUtterance(transcript: String): UtteranceKind {
    val n = normalize(transcript)
    if (n.isEmpty()) return UtteranceKind.EMPTY
    if (isNegatedStop(n)) return UtteranceKind.REPLY
    if (isStopCommand(n)) return UtteranceKind.STOP
    return UtteranceKind.REPLY
}

enum class ConfirmChoice { YES, NO, STOP, UNCLEAR }

private val yesPhrases = listOf(
    "হ্যাঁ পাঠাও", "হ্যাঁ পাঠান", "হ্যাঁ", "হ্যা", "হাঁ", "হা",
    "পাঠাও", "পাঠান", "ঠিক আছে", "ঠিক",
    "yes", "ok", "okay", "ha", "send",
)

private val noPhrases = listOf(
    "পাঠিও না", "পাঠাবে না", "পাঠাব না", "বাতিল করো", "বাতিল",
    "না", "নাহ", "no", "cancel",
)

/** Short yes/no only. A longer sentence is unclear so we never send it by accident. */
fun classifyConfirm(transcript: String): ConfirmChoice {
    var n = normalize(transcript)
    n = n.replace(Regex("[।,!?.…]+"), " ").replace(Regex("\\s+"), " ").trim()
    if (n.isEmpty()) return ConfirmChoice.UNCLEAR
    if (isNegatedStop(n)) return ConfirmChoice.UNCLEAR
    if (isStopCommand(n)) return ConfirmChoice.STOP
    if (n.length > 24) return ConfirmChoice.UNCLEAR
    if (noPhrases.any { n == normalize(it) }) return ConfirmChoice.NO
    if (yesPhrases.any { n == normalize(it) }) return ConfirmChoice.YES
    return ConfirmChoice.UNCLEAR
}
