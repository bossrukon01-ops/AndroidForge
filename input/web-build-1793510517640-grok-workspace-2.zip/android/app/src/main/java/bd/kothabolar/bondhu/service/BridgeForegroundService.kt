package bd.kothabolar.bondhu.service

import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import bd.kothabolar.bondhu.KothaLog

/**
 * Exists only while a message is being read or a reply is being heard.
 * [START_NOT_STICKY] so the system does not resurrect it and burn battery.
 */
class BridgeForegroundService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val mic = ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        val notification = KothaNotifications.build(this)
        if (!promote(notification, mic)) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun promote(notification: android.app.Notification, mic: Boolean): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                if (mic && Build.VERSION.SDK_INT >= 30) {
                    type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                }
                startForeground(KothaNotifications.ID, notification, type)
            } else {
                startForeground(KothaNotifications.ID, notification)
            }
            true
        } catch (error: Exception) {
            KothaLog.w("fgs-type", error)
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    startForeground(
                        KothaNotifications.ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK,
                    )
                } else {
                    startForeground(KothaNotifications.ID, notification)
                }
                true
            } catch (again: Exception) {
                KothaLog.w("fgs-give-up", again)
                false
            }
        }
    }
}
