package bd.kothabolar.bondhu.stt

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import bd.kothabolar.bondhu.KothaLog

/**
 * Armed only during an active session. Stale callbacks from a recognizer we
 * just cancelled are ignored, and a dead recognizer is restarted at most once.
 */
class BargeInListener(private val context: Context) {
    private var recognizer: SpeechRecognizer? = null
    private var epoch = 0

    fun arm(
        onPartial: (String) -> Unit,
        onFinal: (String) -> Unit,
        onFailure: () -> Unit,
    ) {
        disarm()
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            KothaLog.w("stt-unavailable")
            onFailure()
            return
        }
        val mine = epoch
        var restarts = 0
        val rec = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = rec
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit

            override fun onPartialResults(partial: Bundle?) {
                if (mine != epoch) return
                val text = partial?.text().orEmpty()
                if (text.isNotBlank()) onPartial(text)
            }

            override fun onResults(results: Bundle?) {
                if (mine != epoch) return
                val text = results?.text().orEmpty()
                if (text.isNotBlank()) onFinal(text) else onFailure()
            }

            override fun onError(error: Int) {
                if (mine != epoch) return
                val retry = restarts < 1 && (
                    error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                        error == SpeechRecognizer.ERROR_NO_MATCH ||
                        error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                    )
                if (retry) {
                    restarts += 1
                    runCatching { rec.startListening(intent()) }.onFailure {
                        onFailure()
                    }
                } else {
                    KothaLog.w("stt-error:$error")
                    onFailure()
                }
            }
        })
        runCatching { rec.startListening(intent()) }.onFailure {
            KothaLog.w("stt-start", it)
            if (mine == epoch) {
                disarm()
                onFailure()
            }
        }
    }

    fun disarm() {
        epoch++
        val rec = recognizer ?: return
        recognizer = null
        runCatching { rec.cancel() }
        runCatching { rec.destroy() }
    }

    private fun intent(): Intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
    }

    private fun Bundle.text(): String =
        getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
}
