package bd.kothabolar.bondhu.reply

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import bd.kothabolar.bondhu.KothaApp

/** Lock-screen confirmation. The reply text is not in the intent, only yes or no. */
class ConfirmActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val app = context.applicationContext as? KothaApp ?: return
        when (intent?.action) {
            ACTION_ACCEPT -> app.runtime.acceptPending()
            ACTION_REJECT -> app.runtime.rejectPending()
        }
    }

    companion object {
        const val ACTION_ACCEPT = "bd.kothabolar.bondhu.ACCEPT_REPLY"
        const val ACTION_REJECT = "bd.kothabolar.bondhu.REJECT_REPLY"
    }
}
