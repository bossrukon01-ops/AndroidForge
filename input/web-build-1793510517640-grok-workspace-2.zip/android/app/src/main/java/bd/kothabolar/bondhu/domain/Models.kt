package bd.kothabolar.bondhu.domain

/** Android-free snapshot. Rule ids match the studio's policy.ts. */

enum class NoticeCategory { MESSAGE, CALL, MISSED_CALL, STATUS, PROGRESS, OTHER }

data class NoticeMessage(
    val sender: String,
    val text: String,
    val timestamp: Long,
    val mime: String? = null,
    val isSelf: Boolean = false,
)

data class RawNotice(
    val key: String,
    val packageName: String,
    val postedAt: Long,
    val title: String,
    val text: String,
    val bigText: String = "",
    val conversationTitle: String? = null,
    val isGroupConversation: Boolean,
    val isGroupSummary: Boolean,
    val category: NoticeCategory,
    val messagingStyle: Boolean,
    val messages: List<NoticeMessage>,
    val hasReplyAction: Boolean,
    val audioUri: String? = null,
    val channelId: String? = null,
    val fromInitialSnapshot: Boolean = false,
)

data class PolicySettings(
    val aliases: List<String>,
    val enabledPackages: Set<String>,
    val now: Long,
    val recentReplies: List<RecentReply>,
    val readAloud: Boolean = true,
    val voiceReply: Boolean = true,
    val playVoiceNotes: Boolean = true,
)

data class RecentReply(val conversationId: String, val text: String, val at: Long)

sealed interface Decision {
    data class Speak(
        val rule: String,
        val sender: String,
        val body: String,
        val speech: String,
        val conversationId: String,
        val replyable: Boolean,
        val appLabel: String,
        val packageName: String,
        val group: Boolean = false,
    ) : Decision

    data class PlayVoice(
        val sender: String,
        val body: String,
        val conversationId: String,
        val replyable: Boolean,
        val appLabel: String,
        val packageName: String,
        val audioUri: String,
        val group: Boolean = false,
    ) : Decision

    data class AnnounceVoice(
        val sender: String,
        val body: String,
        val speech: String,
        val conversationId: String,
        val replyable: Boolean,
        val appLabel: String,
        val packageName: String,
        val group: Boolean = false,
    ) : Decision

    data class Ignore(val rule: String, val detail: String) : Decision

    data class DeferSummary(val hash: String, val detail: String) : Decision
}

object TargetApps {
    val packages: Map<String, String> = mapOf(
        "com.whatsapp" to "হোয়াটসঅ্যাপ",
        "com.whatsapp.w4b" to "হোয়াটসঅ্যাপ বিজনেস",
        "com.facebook.orca" to "মেসেঞ্জার",
        "com.facebook.mlite" to "মেসেঞ্জার লাইট",
        "org.telegram.messenger" to "টেলিগ্রাম",
    )

    fun label(packageName: String): String = packages[packageName] ?: "বার্তা"
}
