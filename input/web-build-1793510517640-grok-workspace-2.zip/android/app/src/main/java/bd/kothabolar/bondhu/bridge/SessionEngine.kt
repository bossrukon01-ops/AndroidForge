package bd.kothabolar.bondhu.bridge

import bd.kothabolar.bondhu.domain.ConfirmChoice
import bd.kothabolar.bondhu.domain.Decision
import bd.kothabolar.bondhu.domain.PolicySettings
import bd.kothabolar.bondhu.domain.RawNotice
import bd.kothabolar.bondhu.domain.RecentReply
import bd.kothabolar.bondhu.domain.UtteranceKind
import bd.kothabolar.bondhu.domain.classifyConfirm
import bd.kothabolar.bondhu.domain.classifyUtterance
import bd.kothabolar.bondhu.domain.conversationId
import bd.kothabolar.bondhu.domain.dedupeKey
import bd.kothabolar.bondhu.domain.evaluate
import java.util.ArrayDeque

enum class Phase { ASLEEP, SPEAKING, PLAYING, SETTLING, LISTENING, CONFIRMING }

enum class ReplyBlock { NONE, UNSUPPORTED, DISABLED }

data class SpeechItem(
    val id: String,
    val conversationId: String,
    val sender: String,
    val appLabel: String,
    val packageName: String,
    val speech: String,
    val body: String,
    val replyable: Boolean,
    val audioUri: String?,
    val rule: String,
    val at: Long,
    val group: Boolean = false,
    val replyBlock: ReplyBlock = ReplyBlock.NONE,
)

data class PendingReply(
    val sender: String,
    val text: String,
    val destination: String,
    val group: Boolean,
    val conversationId: String,
    val packageName: String,
)

sealed interface Effect {
    data class Speak(val text: String, val id: String) : Effect
    data class Play(val id: String, val uri: String) : Effect
    data class Listen(val sender: String, val conversationId: String) : Effect
    data object CancelAudio : Effect
    data object CancelListen : Effect
    data object ArmSettle : Effect
    data object CancelSettle : Effect
    data class ArmSummary(val hash: String) : Effect
    data class CancelSummary(val hash: String, val conversationId: String) : Effect
    data class Confirm(
        val sender: String,
        val conversationId: String,
        val text: String,
        val destination: String,
        val group: Boolean,
    ) : Effect
    data object ConfirmAgain : Effect
    data object CancelConfirm : Effect
    data class Send(
        val sender: String,
        val conversationId: String,
        val packageName: String,
        val text: String,
    ) : Effect
    data object Sleep : Effect
}

data class LogLine(val at: Long, val rule: String, val outcome: String, val detail: String, val sender: String?)

/**
 * Single-threaded. [KothaRuntime] posts every callback onto one HandlerThread.
 * Asleep + empty queue means no mic, no wake lock, no foreground service.
 * A spoken reply is never sent until the same turn is confirmed.
 */
class SessionEngine {
    var phase: Phase = Phase.ASLEEP
        private set
    var active: SpeechItem? = null
        private set
    var batchAnchor: SpeechItem? = null
        private set
    val queue: ArrayDeque<SpeechItem> = ArrayDeque()
    val log: ArrayDeque<LogLine> = ArrayDeque()
    val recentReplies: ArrayDeque<RecentReply> = ArrayDeque()
    private val seen = ArrayDeque<String>()
    private val childConvs = ArrayDeque<Pair<String, Long>>()
    private val spokenAt = ArrayDeque<Pair<String, Long>>()
    private val floodNoted = ArrayDeque<Pair<String, Long>>()
    private var pendingItem: SpeechItem? = null
    private var pendingText: String? = null
    private var confirmAttempts = 0
    private var seq = 1

    fun pending(): PendingReply? {
        val item = pendingItem ?: return null
        val text = pendingText ?: return null
        return PendingReply(
            sender = item.sender,
            text = text,
            destination = destinationLabel(item),
            group = item.group,
            conversationId = item.conversationId,
            packageName = item.packageName,
        )
    }

    fun seed(notices: List<RawNotice>, now: Long): List<Effect> {
        notices.forEach { markSeen(dedupeKey(it)) }
        pushLog(now, "R-SNAPSHOT", "ignored", "${notices.size}টি পুরনো নোটিফিকেশন সিড।", null)
        return emptyList()
    }

    fun onNotification(notice: RawNotice, settings: PolicySettings): List<Effect> {
        val full = settings.copy(recentReplies = recentReplies.toList())
        val decision = evaluate(notice, full, seen.toSet())
        val effects = mutableListOf<Effect>()
        applyDecision(effects, decision, notice, full)
        return effects
    }

    fun onPlaybackDone(id: String): List<Effect> {
        if (active?.id != id) return emptyList()
        if (phase != Phase.SPEAKING && phase != Phase.PLAYING) return emptyList()
        active = null
        return continueAfterItem()
    }

    fun onSettle(): List<Effect> {
        if (phase != Phase.SETTLING) return emptyList()
        return openListenOrContinue(batchAnchor?.at ?: 0L)
    }

    fun onHeard(transcript: String, now: Long): List<Effect> {
        if (phase == Phase.CONFIRMING) {
            return when (classifyConfirm(transcript)) {
                ConfirmChoice.STOP -> hardStop(now, "স্টপ")
                ConfirmChoice.YES -> finishConfirm(true, now)
                ConfirmChoice.NO -> finishConfirm(false, now)
                ConfirmChoice.UNCLEAR -> onUnclearConfirm(now)
            }
        }
        return when (classifyUtterance(transcript)) {
            UtteranceKind.STOP -> hardStop(now, "স্টপ")
            UtteranceKind.EMPTY -> {
                if (phase != Phase.LISTENING) return emptyList()
                pushLog(now, "R-LISTEN", "empty", "খালি উত্তর পাঠানো হয়নি।", null)
                batchAnchor = null
                afterTurn()
            }
            UtteranceKind.REPLY -> {
                if (phase != Phase.LISTENING) return emptyList()
                val anchor = batchAnchor
                if (anchor == null || !anchor.replyable) {
                    pushLog(now, "R-NO-REPLY", "failed", "রিপ্লাই অ্যাকশন নেই।", anchor?.sender)
                    batchAnchor = null
                    return afterTurn()
                }
                val text = transcript.trim()
                if (text.isEmpty()) {
                    pushLog(now, "R-LISTEN", "empty", "খালি উত্তর পাঠানো হয়নি।", null)
                    batchAnchor = null
                    return afterTurn()
                }
                pendingItem = anchor
                pendingText = text
                confirmAttempts = 0
                phase = Phase.CONFIRMING
                pushLog(now, "R-CONFIRM", "confirm", "উত্তর নিশ্চিত করার অপেক্ষা।", anchor.sender)
                listOf(
                    Effect.Confirm(
                        sender = anchor.sender,
                        conversationId = anchor.conversationId,
                        text = text,
                        destination = destinationLabel(anchor),
                        group = anchor.group,
                    ),
                )
            }
        }
    }

    fun onListenTimeout(now: Long): List<Effect> {
        if (phase != Phase.LISTENING) return emptyList()
        pushLog(now, "R-LISTEN", "empty", "শোনার সময় শেষ। কিছু পাঠানো হয়নি।", null)
        batchAnchor = null
        return afterTurn()
    }

    fun acceptPending(now: Long): List<Effect> = finishConfirm(true, now)

    fun rejectPending(now: Long): List<Effect> = finishConfirm(false, now)

    fun onUnclearConfirm(now: Long): List<Effect> {
        if (phase != Phase.CONFIRMING) return emptyList()
        confirmAttempts += 1
        if (confirmAttempts >= 2) {
            pushLog(now, "R-CONFIRM", "cancelled", "বুঝা যায়নি। কিছু পাঠানো হয়নি।", pendingItem?.sender)
            return finishConfirm(false, now).let { effects ->
                // finishConfirm already logged a cancel; keep a single honest line.
                effects
            }
        }
        pushLog(now, "R-CONFIRM", "retry", "আবার জিজ্ঞাসা।", pendingItem?.sender)
        return listOf(Effect.ConfirmAgain)
    }

    fun halt(now: Long, reason: String): List<Effect> = hardStop(now, reason)

    private fun applyDecision(
        effects: MutableList<Effect>,
        decision: Decision,
        notice: RawNotice,
        settings: PolicySettings,
    ) {
        val now = settings.now
        when (decision) {
            is Decision.Ignore -> {
                markSeen(dedupeKey(notice))
                pushLog(now, decision.rule, "ignored", decision.detail, null)
            }
            is Decision.DeferSummary -> {
                val conv = conversationId(notice)
                val covered = childConvs.any { it.first == conv && now - it.second < 2_000 }
                if (covered) {
                    markSeen(dedupeKey(notice))
                    pushLog(now, "R-SUMMARY-HOLD", "dropped", "সারাংশ বাদ — চাইল্ড এসেছে।", null)
                } else {
                    pushLog(now, "R-SUMMARY-HOLD", "held", decision.detail, null)
                    effects.add(Effect.ArmSummary(decision.hash))
                }
            }
            is Decision.Speak, is Decision.PlayVoice, is Decision.AnnounceVoice -> {
                markSeen(dedupeKey(notice))
                val conv = when (decision) {
                    is Decision.Speak -> decision.conversationId
                    is Decision.PlayVoice -> decision.conversationId
                    is Decision.AnnounceVoice -> decision.conversationId
                    else -> return
                }
                rememberChild(conv, now)
                effects.add(Effect.CancelSummary(summaryHashOf(notice), conv))
                if (flooding(conv, now)) {
                    pushLog(now, "R-FLOOD", "flood", "এক মিনিটে অনেক বার্তা।", null)
                    if (floodNoted.none { it.first == conv && now - it.second < 60_000 }) {
                        floodNoted.addLast(conv to now)
                        val item = itemFrom(decision, now, settings).copy(
                            id = nextId(),
                            speech = "${senderOf(decision)} বলছে: আরও অনেক বার্তা এসেছে",
                            body = "আরও অনেক বার্তা এসেছে",
                            audioUri = null,
                            rule = "R-FLOOD",
                        )
                        effects.addAll(enqueue(item))
                    }
                    return
                }
                pushLog(
                    now,
                    ruleOf(decision),
                    "queued",
                    if (decision is Decision.PlayVoice) "ভয়েস নোট সারিতে।" else "সারিতে।",
                    null,
                )
                effects.addAll(enqueue(itemFrom(decision, now, settings)))
            }
        }
    }

    private fun enqueue(item: SpeechItem): List<Effect> {
        queue.addLast(item)
        if (phase == Phase.SPEAKING || phase == Phase.PLAYING) return emptyList()
        if (phase == Phase.SETTLING) {
            val same = batchAnchor == null || batchAnchor?.conversationId == item.conversationId
            return if (same) listOf(Effect.CancelSettle) + takeNext()
            else listOf(Effect.CancelSettle) + openListenOrContinue(item.at)
        }
        if (phase == Phase.LISTENING) {
            batchAnchor = null
            return listOf(Effect.CancelListen) + takeNext()
        }
        if (phase == Phase.CONFIRMING) {
            clearPending()
            batchAnchor = null
            pushLog(item.at, "R-CONFIRM", "cancelled", "নতুন বার্তার জন্য অনিশ্চিত উত্তর বাতিল।", null)
            return listOf(Effect.CancelConfirm, Effect.CancelListen) + takeNext()
        }
        return takeNext()
    }

    private fun takeNext(): List<Effect> {
        val nextItem = queue.firstOrNull() ?: return openListenOrContinue(batchAnchor?.at ?: 0L)
        val anchor = batchAnchor
        if (anchor != null && anchor.conversationId != nextItem.conversationId) {
            return openListenOrContinue(nextItem.at)
        }
        queue.removeFirst()
        active = nextItem
        batchAnchor = nextItem
        return if (nextItem.audioUri != null) {
            phase = Phase.PLAYING
            listOf(Effect.Play(nextItem.id, nextItem.audioUri))
        } else {
            phase = Phase.SPEAKING
            listOf(Effect.Speak(nextItem.speech, nextItem.id))
        }
    }

    private fun continueAfterItem(): List<Effect> {
        val upcoming = queue.firstOrNull()
        if (upcoming != null && batchAnchor?.conversationId == upcoming.conversationId) return takeNext()
        phase = Phase.SETTLING
        return listOf(Effect.ArmSettle)
    }

    private fun openListenOrContinue(now: Long): List<Effect> {
        val anchor = batchAnchor
        if (anchor?.replyable == true) {
            phase = Phase.LISTENING
            active = null
            pushLog(now, "R-LISTEN", "listen", "উত্তরের জন্য মাইক চালু।", null)
            return listOf(Effect.Listen(anchor.sender, anchor.conversationId))
        }
        if (anchor != null && anchor.replyBlock == ReplyBlock.UNSUPPORTED) {
            pushLog(now, "R-NO-REPLY", "failed", "সরাসরি উত্তরের অ্যাকশন নেই।", null)
            batchAnchor = null
            val text = "সরাসরি উত্তর দেওয়া যাচ্ছে না। এই নোটিফিকেশনে রিপ্লাই বোতাম নেই।"
            val spoken = anchor.copy(
                id = nextId(),
                speech = text,
                body = text,
                replyable = false,
                audioUri = null,
                replyBlock = ReplyBlock.UNSUPPORTED,
            )
            active = spoken
            phase = Phase.SPEAKING
            return listOf(Effect.Speak(text, spoken.id))
        }
        if (anchor != null && anchor.replyBlock == ReplyBlock.DISABLED) {
            pushLog(now, "R-REPLY-OFF", "skipped", "ভয়েস রিপ্লাই বন্ধ।", null)
        }
        batchAnchor = null
        active = null
        if (queue.isNotEmpty()) return takeNext()
        phase = Phase.ASLEEP
        return listOf(Effect.Sleep)
    }

    private fun afterTurn(): List<Effect> {
        active = null
        phase = Phase.ASLEEP
        if (queue.isNotEmpty()) return takeNext()
        return listOf(Effect.Sleep)
    }

    private fun finishConfirm(accept: Boolean, now: Long): List<Effect> {
        if (phase != Phase.CONFIRMING) return emptyList()
        val item = pendingItem
        val text = pendingText?.trim().orEmpty()
        clearPending()
        if (accept && item != null && text.isNotEmpty() && item.replyable) {
            while (recentReplies.size > 20) recentReplies.removeFirst()
            recentReplies.addLast(RecentReply(item.conversationId, text, now))
            pushLog(now, "R-REPLY", "sent", "নিশ্চিত উত্তর পাঠানো হয়েছে।", null)
            batchAnchor = null
            return mutableListOf<Effect>(
                Effect.Send(item.sender, item.conversationId, item.packageName, text),
            ).also { it.addAll(afterTurn()) }
        }
        pushLog(now, "R-REPLY", "cancelled", "উত্তর পাঠানো হয়নি।", null)
        batchAnchor = null
        return afterTurn()
    }

    private fun hardStop(now: Long, reason: String): List<Effect> {
        queue.clear()
        active = null
        batchAnchor = null
        clearPending()
        phase = Phase.ASLEEP
        val detail = if (reason == "কল") {
            "কলের জন্য থামানো হয়েছে।"
        } else {
            "থামানো হয়েছে। কিছু পাঠানো হয়নি।"
        }
        pushLog(now, "R-STOP", "stopped", detail, null)
        return listOf(
            Effect.CancelAudio,
            Effect.CancelListen,
            Effect.CancelSettle,
            Effect.CancelConfirm,
            Effect.Sleep,
        )
    }

    private fun clearPending() {
        pendingItem = null
        pendingText = null
        confirmAttempts = 0
    }

    private fun itemFrom(decision: Decision, now: Long, settings: PolicySettings): SpeechItem {
        fun block(replyable: Boolean): ReplyBlock = when {
            !settings.voiceReply -> ReplyBlock.DISABLED
            !replyable -> ReplyBlock.UNSUPPORTED
            else -> ReplyBlock.NONE
        }
        return when (decision) {
            is Decision.Speak -> SpeechItem(
                nextId(), decision.conversationId, decision.sender, decision.appLabel, decision.packageName,
                decision.speech, decision.body, decision.replyable && settings.voiceReply, null,
                decision.rule, now, decision.group, block(decision.replyable),
            )
            is Decision.PlayVoice -> SpeechItem(
                nextId(), decision.conversationId, decision.sender, decision.appLabel, decision.packageName,
                "", decision.body, decision.replyable && settings.voiceReply, decision.audioUri,
                "R-VOICE", now, decision.group, block(decision.replyable),
            )
            is Decision.AnnounceVoice -> SpeechItem(
                nextId(), decision.conversationId, decision.sender, decision.appLabel, decision.packageName,
                decision.speech, decision.body, decision.replyable && settings.voiceReply, null,
                "R-VOICE-NOFILE", now, decision.group, block(decision.replyable),
            )
            else -> error("not a speech decision")
        }
    }

    private fun flooding(conversationId: String, now: Long): Boolean {
        while (spokenAt.isNotEmpty() && now - spokenAt.first().second >= 60_000) spokenAt.removeFirst()
        val count = spokenAt.count { it.first == conversationId }
        if (count >= 12) return true
        spokenAt.addLast(conversationId to now)
        return false
    }

    private fun rememberChild(conversationId: String, now: Long) {
        while (childConvs.isNotEmpty() && now - childConvs.first().second > 5_000) childConvs.removeFirst()
        childConvs.addLast(conversationId to now)
    }

    private fun markSeen(key: String) {
        if (seen.contains(key)) return
        seen.addLast(key)
        while (seen.size > 300) seen.removeFirst()
    }

    private fun pushLog(at: Long, rule: String, outcome: String, detail: String, sender: String?) {
        log.addFirst(LogLine(at, rule, outcome, detail, sender))
        while (log.size > 50) log.removeLast()
    }

    private fun nextId(): String = "s${seq++}"

    private fun destinationLabel(item: SpeechItem): String {
        val title = item.conversationId.substringAfter("::", item.sender).ifBlank { item.sender }
        return if (item.group) title else item.sender
    }

    private fun senderOf(decision: Decision): String = when (decision) {
        is Decision.Speak -> decision.sender
        is Decision.PlayVoice -> decision.sender
        is Decision.AnnounceVoice -> decision.sender
        else -> ""
    }

    private fun ruleOf(decision: Decision): String = when (decision) {
        is Decision.Speak -> decision.rule
        is Decision.PlayVoice -> "R-VOICE"
        is Decision.AnnounceVoice -> "R-VOICE-NOFILE"
        else -> ""
    }

    private fun summaryHashOf(notice: RawNotice) =
        bd.kothabolar.bondhu.domain.summaryHoldHash(notice)
}
