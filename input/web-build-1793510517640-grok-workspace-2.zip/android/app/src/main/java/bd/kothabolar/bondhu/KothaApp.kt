package bd.kothabolar.bondhu

import android.app.Application
import bd.kothabolar.bondhu.bridge.KothaRuntime
import bd.kothabolar.bondhu.data.SettingsStore
import bd.kothabolar.bondhu.service.KothaNotifications

class KothaApp : Application() {
    lateinit var settings: SettingsStore
        private set
    lateinit var runtime: KothaRuntime
        private set

    override fun onCreate() {
        super.onCreate()
        settings = SettingsStore(this)
        runtime = KothaRuntime(this)
        KothaNotifications.ensure(this)
    }
}
