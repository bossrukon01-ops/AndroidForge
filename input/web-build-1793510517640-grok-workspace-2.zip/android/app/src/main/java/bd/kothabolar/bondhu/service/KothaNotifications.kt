package bd.kothabolar.bondhu.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import bd.kothabolar.bondhu.R
import bd.kothabolar.bondhu.reply.ConfirmActionReceiver
import bd.kothabolar.bondhu.ui.MainActivity

object KothaNotifications {
    const val ID = 42
    const val CONFIRM_ID = 43
    const val CHANNEL = "kotha.session"
    const val CONFIRM_CHANNEL = "kotha.confirm"

    fun ensure(context: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val manager = context.getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL,
            context.getString(R.string.channel_name),
            NotificationManager.IMPORTANCE_LOW,
        )
        channel.setSound(null, null)
        channel.enableVibration(false)
        channel.description = context.getString(R.string.channel_desc)
        manager.createNotificationChannel(channel)

        val confirm = NotificationChannel(
            CONFIRM_CHANNEL,
            context.getString(R.string.confirm_channel_name),
            NotificationManager.IMPORTANCE_HIGH,
        )
        confirm.setSound(null, null)
        confirm.enableVibration(false)
        confirm.description = context.getString(R.string.confirm_channel_desc)
        manager.createNotificationChannel(confirm)
    }

    fun build(context: Context): Notification {
        return NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(context.getString(R.string.app_name))
            .setContentText(context.getString(R.string.session_text))
            .setOngoing(true)
            .setSilent(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setContentIntent(openApp(context))
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    fun showConfirm(context: Context, destination: String, text: String, group: Boolean) {
        if (!canPost(context)) return
        val title = if (group) "$destination গ্রুপে পাঠাবেন?" else "$destinationকে পাঠাবেন?"
        val body = text.trim().take(180)
        val notification = NotificationCompat.Builder(context, CONFIRM_CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(Notification.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp(context))
            .addAction(0, "পাঠাও", broadcast(context, accept = true))
            .addAction(0, "বাতিল", broadcast(context, accept = false))
            .build()
        manager(context).notify(CONFIRM_ID, notification)
    }

    fun cancelConfirm(context: Context) {
        manager(context).cancel(CONFIRM_ID)
    }

    fun listenerEnabled(context: Context): Boolean {
        val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners")
            ?: return false
        val mine = ComponentName(context, KothaNotificationListener::class.java).flattenToString()
        return flat.split(":").any { it.equals(mine, ignoreCase = true) }
    }

    private fun canPost(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < 33) return true
        return ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun openApp(context: Context): PendingIntent {
        return PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
    }

    private fun broadcast(context: Context, accept: Boolean): PendingIntent {
        val intent = Intent(context, ConfirmActionReceiver::class.java).setAction(
            if (accept) ConfirmActionReceiver.ACTION_ACCEPT else ConfirmActionReceiver.ACTION_REJECT,
        )
        return PendingIntent.getBroadcast(
            context,
            if (accept) 7 else 8,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
    }

    private fun manager(context: Context): NotificationManager {
        return context.getSystemService(NotificationManager::class.java)
    }
}
