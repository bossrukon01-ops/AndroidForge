package bd.kothabolar.bondhu.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import bd.kothabolar.bondhu.KothaLog

class VoiceNotePlayer(private val context: Context) {
    private var player: MediaPlayer? = null

    fun play(uri: String, onDone: () -> Unit, onFail: () -> Unit) {
        stop()
        val mp = MediaPlayer()
        player = mp
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build(),
            )
            mp.setDataSource(context, Uri.parse(uri))
            mp.setOnCompletionListener {
                stop()
                onDone()
            }
            mp.setOnErrorListener { _, what, extra ->
                KothaLog.w("voice-error:$what:$extra")
                stop()
                onFail()
                true
            }
            mp.setOnPreparedListener { ready ->
                if (player === ready) ready.start()
            }
            mp.prepareAsync()
        } catch (error: Exception) {
            KothaLog.w("voice-open", error)
            stop()
            onFail()
        }
    }

    fun stop() {
        val current = player ?: return
        player = null
        runCatching { current.stop() }
        runCatching { current.release() }
    }
}
